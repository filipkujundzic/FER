#include <string.h>
#include <ctype.h>
#include "funkcije15.h"


int sazetak(char *ulaz)
{	
	int suma=0,i;
	if(ulaz[0]=='\0' || ulaz==NULL) return 0;
	for(i=0;ulaz[i]!='\0';i++)
	{
		suma+=ulaz[i];
	}
	return suma%128;
}

void dodajZnak(char *ulaz, int broj)
{
	ulaz[strlen(ulaz)]=broj;
	
}