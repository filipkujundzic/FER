int sazetak(char *ulaz);
void dodajZnak(char *ulaz, int broj);