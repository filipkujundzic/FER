#include <stdio.h>
#include <string.h>
#include "funkcije15.h"

int main(void)
{
	char s[201],tmp[150];
	int i,k=0;
	gets(s);
	for(i=0;i<=strlen(s);i++)
	{	
		if(s[i]!=' ') tmp[k]=s[i];
		if(s[i]==' ' ||s[i]=='\0')
		{
			tmp[k]='\0';
			printf("%s ",tmp);
			printf("%d ",sazetak(tmp));
			dodajZnak(tmp,sazetak(tmp));
			puts(tmp);
			k=-1;
		}
		k++;
	}
	return 0;
}
