#include <stdio.h>
#include "funkcije03.h"

int main(void)
{
	int skup1[20],skup2[20],un[20];
	int tmp,postoji=0;
	int s1=0,s2=0,i;
	printf("Skup 1: \n");
	do
	{
		scanf("%d",&tmp);
		for(i=0;i<s1;i++) if(skup1[i]==tmp) {postoji=1; break;}
		if(tmp>0 && postoji==0)
		{
			skup1[s1]=tmp;	
			s1++;
		}
	postoji=0;
	}while(tmp>0);
	postoji=0;
	printf("Skup 2: \n");
	do
	{
		scanf("%d",&tmp);
		for(i=0;i<s2;i++) if(skup2[i]==tmp) {postoji=1; break;}
		if(tmp>0 && postoji==0)
		{
			skup2[s2]=tmp;
			s2++;
		}
	postoji=0;		
	}while(tmp>0);
	
	for(i=0;i<s1;i++) printf("%d ",skup1[i]);
	printf("\n");
	for(i=0;i<s2;i++) printf("%d ",skup2[i]);	

	
	unija(s1,&skup1[0],s2,&skup2[0],s1+s2,&un[0]);
	printf("\n");	
	printf("Skup 1 %s podskup skupa 2.\n",(je_podskup(s1,&skup1[0],s2,&skup2[0]))?("JE"):("NIJE"));
	printf("Skup 2 %s podskup skupa 1.",(je_podskup(s2,&skup2[0],s1,&skup1[0]))?("JE"):("NIJE"));
	return 0;				
}