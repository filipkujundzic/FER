#include "funkcije03.h"
#include <stdio.h>
#define MAKS 20

void unija(int n1, int *s1, int n2, int *s2, int nrez, int *rez)
{
	int i,j,pom,c=1,k=0;
	for(i=0;i<n1;i++)
	{
		*(rez+i)=*(s1+i);
	}
	
	pom=i;
	for(i=0;i<n2;i++)
	{
		for(j=0;j<pom;j++)
		{
			if(*(s2+i)==*(rez+j)) 
			{
				c=0;
			}
		}
	
	if(c==1) 
	{
		k++;
		*(rez+k+pom-1)=*(s2+i);
	}
	c=1;
	}
		
	printf("\nUnija: \n");
	for(i=0;i<pom+k;i++)
	printf("%d ",rez[i]);
	
}




int je_podskup(int npodskup, int *podskup, int nskup, int *skup)
{
	int i1,j1,br=0;
	for(i1=0;i1<npodskup;i1++)
	{
		for(j1=0;j1<nskup;j1++)
		if(*(podskup+i1)==*(skup+j1)) br++;
	}
	if(br==npodskup) return 1;
	else return 0;
}