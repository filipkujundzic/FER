#include <stdio.h>
#include <string.h>
#include "funkcije09.h"

int main(void)
{	
	char s1[301],s2[301];
	char tmp1[6],tmp2[6];
	int n,len1,len2,i,j;
	int sol=0;
	gets(s1);
	gets(s2);
	scanf("%d",&n);
	len1=strlen(s1);
	len2=strlen(s2);
	
	for(i=0;i<=len1-n;i++)
	{	
		genPodniz(s1,tmp1,i,n);
		for(j=0;j<=len2-n;j++)
		{
			genPodniz(s2,tmp2,j,n);
			sol+=nizoviJednaki(tmp1,tmp2);
		}
	}
	printf("Rjesenje je:%lf\n",sol*2./(len1+len2+2-2*n));
	return 0;	
}