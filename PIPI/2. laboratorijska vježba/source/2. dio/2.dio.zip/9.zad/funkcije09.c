#include "funkcije09.h"
#include <string.h>

void genPodniz(char *nizUlaz, char *podNiz, int pocPozicija, int duljPodniz)
{
	int i;
	for(i=pocPozicija;i<(duljPodniz+pocPozicija);i++)
	{
		podNiz[i-pocPozicija]=nizUlaz[i];
	}
	podNiz[duljPodniz]='\0';
}


int nizoviJednaki (char *niz1, char *niz2)
{	
	while(1==1)
	{
		if(*niz1 != *niz2) return 0;
		if(*niz1 == '\0') return 1;
		niz1++;
		niz2++;
	}
}
		