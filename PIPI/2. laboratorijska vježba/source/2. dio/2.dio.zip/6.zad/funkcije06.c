#include <stdio.h>
#include <string.h>
#include "funkcije06.h"

int brojNeSlova (char *str)
{
	int i,br=0;
	i=strlen(str);
	for(i=0;i<strlen(str);i++)
	{
		if(!((str[i]>='A' && str[i]<='Z') || (str[i]>='a' && str[i]<='z')))
		br++;
	}
	return br;
}

void caesarEncrypt (char *nizUlaz, char *nizIzlaz, int kljucKriptiranja)
{
	int i;
	for(i=0;i<strlen(nizUlaz);i++)
	{
		if(nizUlaz[i]>='A' && nizUlaz[i]<='Z') nizIzlaz[i]=(nizUlaz[i]-'A')%26+kljucKriptiranja+'A';
		if(nizUlaz[i]>='a' && nizUlaz[i]<='z') nizIzlaz[i]=(nizUlaz[i]-'a')%26+kljucKriptiranja+'a';
	}
}