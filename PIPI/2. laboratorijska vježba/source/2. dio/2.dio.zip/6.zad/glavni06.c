#include <stdio.h>
#include <string.h>
#include "funkcije06.h"

int main(void)
{
	char niz[101],kopija[101]={'\0'},rez[101]={'\0'};
	int key,i;
	do{
		printf("Unesite niz: ");
		gets(niz);
	}while(brojNeSlova(niz));
	do{
		printf("Unesite kljuc: ");
		scanf("%d",&key);
	}while(!(key>=1 && key<=25));
	for(i=0;i<strlen(niz);i++) kopija[i]=niz[i];
	caesarEncrypt (&kopija[0], &rez[0], key);
	printf("Originalni niz: ");
	puts(niz);
	printf("Kriptirani niz: ");
	puts(rez);
	return 0;
}
	
