#include <stdio.h>
#include "funkcije07.h"

int main(void)
{
	char s[2001];
	int i=0,od,rj;
	do{
	scanf("%c",&s[i]);
	}while(s[i++]!='\0');
	rj=br_rijeci(s);
	if(rj)
	{
		od=br_odlomaka(s);
		printf("Zadani tekst sadrzi rijeci/odlomaka: %d/%d\n",rj,od);
	}
	else printf("Zadani tekst nema rijeci");
	return 0;
}