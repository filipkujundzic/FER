#include <string.h>
#include <ctype.h>
#include "funkcije07.h"

int br_odlomaka(char * tekst)
{
	int i=0,odlomci=0;
	for(i=0;i<=strlen(tekst);i++)
	{
		if(tekst[i]=='\n')
		{
			if(tekst[i-1]=='.' || tekst[i-1]=='!' || tekst[i-1]=='?') odlomci++; 
		}
		else if(tekst[i]=='\0'&&tekst[i-1]!='\0') odlomci++;
		
	}
	return odlomci;
}

int br_rijeci(char * tekst)
{
	int i1,rijeci=1;
	for(i1=0;i1<strlen(tekst);i1++)
	if((ispunct(tekst[i1+1]) || isspace(tekst[i1+1])) && isalpha(tekst[i1])) rijeci++;	
	return rijeci;
}