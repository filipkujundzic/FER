int br_odlomaka(char * tekst);
int br_rijeci(char * tekst);
