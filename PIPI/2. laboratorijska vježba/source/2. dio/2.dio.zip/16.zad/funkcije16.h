void minNiz(int *m,int brred,int brstup,int maksstup,int *maks,int *min);
int dobreDimenzije(int maxred,int maxstup,int brred,int brstup);