#include <stdio.h> 
#include "funkcije16.h" 
#define MAKS 20

int main(void)
{
	int polje[MAKS][MAKS],brRed,brStup,najmanji,najveci;
	int i, j;
	do{
		scanf("%d %d",&brRed,&brStup);
	}while(!dobreDimenzije(MAKS,MAKS,brRed,brStup));
	for(i=0;i<brRed;i++)
	{
		for(j=0;j<brStup;j++)
		{
			scanf("%d",&polje[i][j]);
		}
	}
	minNiz(&polje[0][0],brRed,brStup,MAKS,&najveci,&najmanji);
	for(i=0;i<brRed;i++)
	{
		for(j=0;j<brStup;j++)
		{
			printf("%3d",polje[i][j]);	
		}
		printf("\n");
	}
	printf("Max: %d\nMin: %d\n",najveci,najmanji);
	return 0;
}	
