#include "funkcije16.h" 

void minNiz(int *m,int brred,int brstup,int maksstup,int *maks,int *min)
{
	int i,j;
	int *p=m;
	*maks=*m;
	*min=*m;
	for(i=0;i<brred;i++)
	{
		for(j=0;j<brstup;j++)
		{
			if(*(p+i*maksstup+j)>*maks) *maks=*(p+i*maksstup+j);
			else if(*(p+i*maksstup+j)>*min) *min=*(p+i*maksstup+j)>*min;
		}
	}
}



int dobreDimenzije(int maxred,int maxstup,int brred,int brstup)
{
	if(brred<=maxred && brstup<=maxstup) return 1;
	return 0;
}
	
		
	