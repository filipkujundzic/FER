#include <stdio.h>
#include "funkcije14.h"

int main(void)
{
	char a[10],b[10],c;
	int br1=0,br2=0;
	printf("Prvi: "); gets(a);
	printf("Drugi:"); gets(b);
	printf("Operator: "); scanf("%c",&c);
	br1=nizUint(a,br1);
	br2=nizUint(b,br2);
	printf("%d",br1);
	printf("%d",br2);
	if(!(nizUint(a,br1) && nizUint(b,br2))) 
	{
		printf("Greska");
		return 0; 
	}
	printf("Rezulatat: %d",matemOp(br1,br2,c));
	return 0;
}
