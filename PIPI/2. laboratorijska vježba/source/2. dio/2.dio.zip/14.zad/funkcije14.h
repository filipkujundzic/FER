int nizUint(char p[],int rez);
int matemOp(int x,int y,char c);