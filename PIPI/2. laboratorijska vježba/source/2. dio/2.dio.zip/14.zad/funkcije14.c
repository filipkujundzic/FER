#include <string.h>
#include <math.h> 
#include "funkcije14.h"

int nizUint(char p[],int rez)
{
	int i,l=strlen(p);
	for(i=0;i<l;i++)
	{
		if(!(p[i]>='0' && p[i]<='9'))
		return -1;
	}
	for(i=0;i<l;i++)
	{
		rez+=(p[i]-'0')*pow(10,l-i-1);
	}
	return rez;	
}

int matemOp(int x,int y,char c)
{	
	int rez;
	if(!(c=='+' || c=='-')) return 0;
	if(c=='+') rez=x+y;
	else if(c=='-') rez=x-y;
	return rez;
}