#include <stdio.h>
#include <string.h>
#include "funkcije04.h"

void generirajNiz(char *znakovi, int duljinaNiza, char *genNiz)
{
	int l,i,k=0;
	l=strlen(znakovi);
	if(duljinaNiza > l) 
	{
		for(i=0;i<duljinaNiza;i++)
		{
			genNiz[i]=znakovi[i%l];
		}
	}
	if(duljinaNiza <= l)
	{
		for(i=l-duljinaNiza;i<l;i++)
		{	
			genNiz[k]=znakovi[i];
			k++;
		}
	}
	
}

int dobarNiz (char *niz)
{
	int p=0,i1,j1;
	for(i1=0;i1<strlen(niz);i1++)
	{
		for(j1=i1+1;j1<strlen(niz);j1++)
		{
			if(niz[i1]==niz[j1])
			{
				p=1;
				break;
			}
		}
	}
	if(p==1) return 0;
	else return 1;
}
		