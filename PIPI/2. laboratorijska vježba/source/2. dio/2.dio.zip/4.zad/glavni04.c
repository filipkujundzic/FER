#include <stdio.h>
#include "funkcije04.h"

int main(void)
{
	char c[21],rez[101]={"\0"};
	int n;
	do{
		printf("Unesite niz: \n");
		gets(c);
	}while(dobarNiz(c)==0);
	do{
		printf("Unesite duljinu generiranog niza :\n");
		scanf("%d",&n);
	}while(n<0 || n>100);
	printf("Niz: ");
	puts(c);
	generirajNiz(&c[0],n,&rez[0]);
	printf("Generirani niz: ");
	puts(rez);
	return 0;
}

 