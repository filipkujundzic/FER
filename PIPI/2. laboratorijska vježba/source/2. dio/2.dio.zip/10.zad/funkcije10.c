#include "funkcije10.h"
#include <string.h>

int brojPonavljanja(char niz[], char znak)
{
	int i,bp=0;
	int l;
	char *p=&niz[0];
	l=strlen(niz);
	for(i=0;i<l;i++)
	{
		if(niz[i]==znak)
		{
			p=&niz[i];
			break;
		}
	}
	i=0;
	while(*(p+i)==znak)
	{
		bp++;
		i++;
	}
	return bp;
}

void kodiraj(char src[], char dest[])
{
	int i=0,j=0,br;
	for(i=0;src[i]!='\0';)
	{
		br=brojPonavljanja(&src[i],src[i]);
		dest[j++]=src[i];
		dest[j++]=br+'0';
		i+=br;
	}
}
		
