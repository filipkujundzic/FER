#include "funkcije10.h"
#include <stdio.h>

int main(void)
{
	char niz[101],kod[101];
	gets(niz);
	kodiraj(niz,kod);
	puts(niz);
	puts(kod);
	return 0;
}