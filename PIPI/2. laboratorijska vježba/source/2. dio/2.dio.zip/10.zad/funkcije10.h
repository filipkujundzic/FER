int brojPonavljanja(char niz[], char znak);
void kodiraj(char src[], char dest[]);