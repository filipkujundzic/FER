#include <stdio.h>
#include "funkcije08.h"

int main(void)
{
	char s[201];
	char l,d;
	int da=0,ne=0;
	int lijevi=0,desni=0;
	printf("Upisite izraz koji zelite provjeriti: ");
	gets(s);
	do{
		printf("Upisite lijevi i desni granicnik: ");
		scanf(" %c%c",&l,&d);
		if(l=='\\' || d=='\\') break;
		brLijevihiDesnihGranicnika (s,l,d,&lijevi,&desni);
		printf("Izraz %s %s ispravan obzirom na granicnike %C%c\n",s,(izrazJeIspravan(lijevi,desni))?("JE"):("NIJE"),l,d);
		if(izrazJeIspravan(lijevi,desni)) da++;
		else ne++;
	}while(l!='\\' && d!='\\');
	printf("Izraz %s je djelomicno ispravan: ispravan obzirom na %d granicnik(a),a neispravan obzirom na %d granicnik(a)",s,da,ne);
	return 0;
} 
	