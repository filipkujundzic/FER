#include "funkcije08.h"
#include <string.h>

void brLijevihiDesnihGranicnika (char *znNiz, char lijevi, char desni, int *brLijevih, int *brDesnih)
{
	int i,l,a=0,b=0;
	l=strlen(znNiz);
	for(i=0;i<l;i++)
	{
		if(znNiz[i]==lijevi) a++;
		if(znNiz[i]==desni)  b++;
	}
	*brLijevih=a;
	*brDesnih=b;
}

int izrazJeIspravan(int brLijevih,int brDesnih)
{
	if(brLijevih == brDesnih && (brLijevih!=0 || brDesnih!=0)) return 1;
	else return 0;
}
	