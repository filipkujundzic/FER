#include <stdio.h>
#include "funkcije12.h"

int main(void)
{	
	char tekst[1501];
	int prvi,drugi;
	gets(tekst);
	pronadi(tekst,&prvi,&drugi);
	if(prvi=='A' && drugi=='I') printf("\nJezik na kojem je tekst vjerojatno napisan je: Hrvatski");
	else if(prvi=='E' && drugi=='T') printf("\nJezik na kojem je tekst vjerojatno napisan je: Engleski");
	else if(prvi=='E' && drugi=='N') printf("\nJezik na kojem je tekst vjerojatno napisan je: Njemacki");
	else printf("\nJezik na kojem je tekst vjerojatno napisan je: Nepoznat");
	return 0;
}