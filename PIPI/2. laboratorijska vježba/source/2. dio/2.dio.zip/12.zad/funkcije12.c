#include "funkcije12.h"
#include <string.h>
#include <stdio.h>
 
void pronadi(char niz[],int *a,int *b)
{	
	int tmp[26]={0};
	int t;
	int i,najveci1,najveci2;
	for(i=0;i<strlen(niz);i++)
	{
		if(niz[i]>='A' && niz[i]<='Z') tmp[25-('Z'-niz[i])]++;
		if(niz[i]>='a' && niz[i]<='z') tmp[25-('z'-niz[i])]++;
	}
	for(i=0;i<26;i++) printf("%d ",tmp[i]);
	najveci1=tmp[0]; *a=0;
	najveci2=tmp[1]; *b=1;	
	if(tmp[1]>tmp[0]) 
	{
		t=najveci1;
		najveci1=najveci2;
		najveci2=t;
		*a=1; *b=0;
	}
	
	for(i=2;i<25;i++)
	{
		if(tmp[i]>najveci1) 
		{
			*b=*a;
			*a=i;
			najveci2=najveci1;
			najveci1=tmp[i];
		}
		if(tmp[i]>=najveci2 && tmp[i]<najveci1)
		{ 
			najveci2=tmp[i];
			*b=i;
		}
	}
	*a+=65;
	*b+=65;
}