#include <stdio.h>
 
void prosjek(int *mat,int brred,int brstup,int maks,double *red,double *stup)
{	
	int i,j;
	for(i=0;i<brred;i++) 
	{
		for(j=0;j<brstup;j++)
		{
			red[i]+=(double) mat [i*maks+j] /brstup;		
			stup[j]+=(double) mat [i*maks+j]/brred;
		}
	}
}
			
			
	
	