    #include <string.h>
    #include <ctype.h>
    #define MAXSTUP 21

    void rastavi(char *niz, int brojRijeci, int maxRijeci, int duljinaRijeci, char *polje){
            int i, j, indeks = 0;

            /*po retcima*/
            for (i = 0; i < maxRijeci; ++i){

                    /* po stupcima */
                    for(j = 0; j <= duljinaRijeci; ++j){

                            /*provjerava je li trenutni znak slovo*/
                            if ( isalpha( niz[indeks] ) ) *(polje + i*MAXSTUP + j) = niz[indeks++];
                            else *(polje + i*MAXSTUP + j) = '\0';

                            /*stavljanje '\0' na kraj retka*/
                            if (j == duljinaRijeci){
                            *(polje + i*MAXSTUP + j) = '\0';
                            }

                    }

                    /*prebacuje indeks na iducu rijec*/
                    while(1){
                            if ( !isalpha(niz[indeks])){
                                    if ( isalpha ( niz[indeks + 1] ) ){
                                            indeks++;
                                            break;
                                    }
                                    if ( niz[indeks] == '\0' ) break;
                                    ++indeks;
                            }
                            else ++indeks;
                    }


            }

            return;
    }

    int brojRijeci(char *polje, int brRijeci){
            int i, broj = 0;
            for (i = 0; i < brRijeci; ++i){
                    if ( *(polje + i*MAXSTUP) != '\0' && isalpha(*(polje + i*MAXSTUP))) ++broj;
            }
            return broj;
    }

