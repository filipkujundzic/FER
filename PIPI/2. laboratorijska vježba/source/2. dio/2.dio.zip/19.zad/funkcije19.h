void rastavi(char *niz, int brojRijeci, int maxRijeci, int duljinaRijeci, char *polje);
int brojRijeci(char *polje,int brojRijeci);