#include <stdio.h>
#include "funkcije13.h"
#define MAKS 5

int main( void )
{
	int sekunde,h,m,s;
	char hc[100],mc[100],sc[100];
	scanf("%d",&sekunde);

	hms(sekunde,&h,&m,&s);

	h = intUNiz( h, hc ); 
	m = intUNiz( m, mc );	
	s = intUNiz( s, sc );	

	if (h*m*s == 0) return 0;	
	printf("%s", dodajNiz( dodajNiz( dodajNiz(hc,":"), dodajNiz(mc,":") ), sc) );
	
	return 0;
}