#include "funkcije17.h"
#include <math.h>

void kvadrat(int *p,int red,int stup,int maxStup)
{
	int i,j,x;
	for(i=0;i<red;i++)
	{
		for(j=0;j<stup;j++)
		{
			x=*(p+i*maxStup+j);
			*(p+i*maxStup+j)=pow(x,2);
		}
	}
	return;
}

void minStupac(int *p,int *min,int brRed,int brStup,int maxStup)
{
	int i=0,j=0;
	for(j=0;j<brStup;j++)
	{
		*(min+j)=*(p+i*maxStup+j);
		for(i=0;i<brRed;i++)
		if(*(p+i*maxStup+j)<=*(min+j))
		*(min+j)=*(p+i*maxStup+j);
	}
	return;
}

