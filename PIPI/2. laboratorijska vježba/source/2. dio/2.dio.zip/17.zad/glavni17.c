#include <stdio.h>
#include "funkcije17.h"
#define MAX 10

int main(void)
{
	int polje[MAX][MAX],brRed,brStup,min[MAX];
	int i,j;
	do{
		scanf("%d %d",&brRed,&brStup);
	}while(brRed<=0 || brStup<=0 || brRed>MAX || brStup>MAX);
	for(i=0;i<brRed;i++)
	for(j=0;j<brStup;j++)
	scanf("%d",&polje[i][j]);
	kvadrat(&polje[0][0],brRed,brStup,MAX);
	minStupac(&polje[0][0],&min[0],brRed,brStup,MAX);
	for(i=0;i<brRed;i++)
	{
		for(j=0;j<brStup;j++)
		printf("%4d",polje[i][j]); 
		printf("\n");
	}
	for(i=0;i<brStup;i++)
	printf("%4d",min[i]);
	printf("\n");
	return 0;
}

