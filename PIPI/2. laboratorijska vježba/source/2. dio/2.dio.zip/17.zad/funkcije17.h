void kvadrat(int *p,int red,int stup,int maxStup);
void minStupac(int *p,int *min,int brRed,int brStup,int maxStup);