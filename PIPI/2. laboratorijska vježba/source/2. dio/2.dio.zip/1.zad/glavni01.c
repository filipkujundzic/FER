#include <stdio.h>
#include <math.h>
#include "funkcije.h"

int main(void)
{
	int n,i,k;
	int post[100];
	double lat[100]={0},long1[100]={0};
	do{
		scanf("%d",&n);
	}while(n<3 || n>100);
	for(i=0;i<n;i++)
	{
		printf("Upisite postanski broj i koordinate %d.grada:",i+1);
		scanf("%d %lf %lf",&post[i],&lat[i],&long1[i]);
		
	}
	for(i=0;i<n;i++)
	{
		stupnjeviURadijane(&lat[i]);
		stupnjeviURadijane(&long1[i]);
		
	}
	printf("Medusobne udaljenosti gradova:\n");
	for(i=0;i<n;i++)
	{
		for(k=i+1;k<n;k++)
		printf("%d - %d : %lf km\n",post[i],post[k],izracunajUdaljenost(&lat[i],&lat[k],&long1[i],&long1[k]));
	}
	return 0;
}
	
	


