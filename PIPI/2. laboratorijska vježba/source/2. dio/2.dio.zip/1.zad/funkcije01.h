void stupnjeviURadijane(double *x);
double izracunajUdaljenost(double *lat1,double *lat2,double *long1,double *long2);