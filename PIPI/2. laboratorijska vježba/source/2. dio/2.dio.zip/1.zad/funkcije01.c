#include <stdio.h>
#include <math.h>

void stupnjeviURadijane(double *x)
{
	double pi=3.141592;
	*x=(*x/180)*pi;   
	return;
}

double izracunajUdaljenost(double *lat1,double *lat2,double *long1,double *long2)
{
	double a,d,R=6371;
	a=pow(sin((*(lat2)-*lat1)/2),2)+cos(*lat1)*cos(*lat2)*pow(sin((*long2-*long1)/2),2);
	d=R*2*atan2(sqrt(a),sqrt(1-a));
	return d;
}