#include <stdio.h>
#include <ctype.h>
#include "funkcije02.h"

int main(void)
{
	char c;
	unsigned int x0,a,i=0;
	while(1==1)
	{
		printf("Upisite sjeme: ");
		scanf("%u",&x0);
		if(x0==0) return 0;
		setSeed(x0);
		a=getRand(),i=0;
		while(i!=a)
		{
			c=getRand();
			if((c>='A' && c<='Z') || (c>='a' && c<='z') || c==',' || c==' ')
			{
				printf("%c",c);
				i++;
			}
		}
		printf(".\n");
	}
return 0;
}