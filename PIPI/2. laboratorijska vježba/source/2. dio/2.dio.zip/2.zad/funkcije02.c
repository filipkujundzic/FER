#include "funkcije02.h"

#define A 9001
#define C 29
#define M 225

static unsigned int xi=1;

void setSeed(unsigned int seed)
{
	xi=seed;
}

int getRand(void)
{
	xi=(A*xi+C)%M;
	return xi;
}
