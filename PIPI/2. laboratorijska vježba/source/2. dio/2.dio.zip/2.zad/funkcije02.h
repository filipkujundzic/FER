void setSeed(unsigned int seed);
int getRand(void);