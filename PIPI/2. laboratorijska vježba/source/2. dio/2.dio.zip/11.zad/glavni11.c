#include <stdio.h>
#include "funkcije11.h"
#define MAX 100
#define max 10

int main(void)
{
	int c;
	char ulaz[MAX+1],uzorak[max+1];
	gets(ulaz);
	gets(uzorak);
	do{
		c=izbaci(ulaz,uzorak);
	}while(c);
	puts(ulaz);
	return 0;
}