#include <stdio.h>

char* nadjiPodniz(char *ulaz, char *uzorak)
{
	int i,len_ul,len_uz,k=0,kopija;
	for(i=0;ulaz[i]!='\0';i++); len_ul=i;
	for(i=0;uzorak[i]!='\0';i++); len_uz=i;
	kopija=len_uz;
	for(i=0;i<=len_ul;i++)
	{
		
		if(len_uz==0)
		{		 
			return &ulaz[i-kopija];
		}
		if(ulaz[i]!=uzorak[k]) 
		{
			len_uz=kopija;
			k=0;
		}
		if(ulaz[i]==uzorak[k]) 
		{
			len_uz--;
			k++;
		}
		
	}
	return NULL;
} 
		
int izbaci(char *ulaz, char *uzorak)
{	
	int l,i;
	char *p=nadjiPodniz(ulaz,uzorak);
	for(i=0;uzorak[i]!='\0';i++); l=i;
	if(p!=NULL)
	{
		for(i=0;ulaz[i]!='\0';i++)	
		*(p+i)=*(p+i+l);
		return 1;
	}
	return 0;
}

	