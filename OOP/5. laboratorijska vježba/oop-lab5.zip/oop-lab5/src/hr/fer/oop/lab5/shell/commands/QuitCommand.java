package hr.fer.oop.lab5.shell.commands;

import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
/**
 * Razred predstavlja komandu quit za ljusku
 * @author Filip Kujundzic
 *
 */
public class QuitCommand extends AbstractCommand{
	
	/**
	 * Konstruktr naredbe quit; naslje�uje ime komande i njen opis
	 */
	public QuitCommand() {
		super("quit","Quits the MyShell.");
	}

	/**
	 * Naredba za izvr�avanje komande
	 * 
	 * @param executioner
	 *            okru�enje za rad s ljuskom
	 * @param message
	 *            argument koji predajemo naredbi
	 */
	@Override
	public CommandStatus execute(Environment e, String s) {
		return CommandStatus.EXIT;
	}
	
	
}
