package hr.fer.oop.lab5.shell.commands;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;

/**
 * Razred predstavlja naredbu type kojom ispisujemo sadr�aj datoteke koja ima
 * predanu putanju na ljusku (zaslon)
 * 
 * @author Filip Kujundzic
 *
 */
public class TypeCommand extends AbstractCommand {

	/**
	 * Konstruktor naredbe type. Naslje�uje ime komande i njen opis.
	 */
	public TypeCommand() {
		super("type", "Prints the content of a file.");
	}

	/**
	 * Naredba kojom se izvr�ava komanda. Prima dva argumenta.
	 * 
	 * @param executioner
	 *            okru�enje kojim upravljamo ljuskom
	 * @param message
	 *            argument koji prima naredba
	 */
	@Override
	public CommandStatus execute(Environment executioner, String message) {
		if (message == null) {
			executioner.writeLn("Not enough input arguments for command type");
			return CommandStatus.CONTINUE;
		}

		/**
		 * Nova datoteka koju dobivamo "lijepljenjem" imena
		 * datoteke koju �elimo ispisati na trenutnu putanju
		 */
		File file = new File(executioner.getCurrentPath() + "\\" + message);

		if (file.exists() && file.isFile()) {
			try {
				BufferedReader br = new BufferedReader(new FileReader(file));
				String line = null;
				try {
					while ((line = br.readLine()) != null)
						executioner.writeLn(line);
				} catch (IOException e) {
					e.printStackTrace();
				}
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			executioner.writeLn("No such file");
		}
		return CommandStatus.CONTINUE;
	}
}
