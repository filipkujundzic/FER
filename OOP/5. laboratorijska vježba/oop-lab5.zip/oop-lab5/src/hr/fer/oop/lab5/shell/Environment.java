package hr.fer.oop.lab5.shell;

import java.nio.file.Path;

/**
 * Su�elje definira metode potrebne za rad s ljuskom.
 * 
 * @author Filip Kujundzic
 *
 */
public interface Environment {

	/**
	 * Metoda �ita jedan redak une�en preko standardnog ulaza.
	 * 
	 * @return Pro�itani redak u obliku stringa
	 */
	public String readLine();

	/**
	 * Metoda za pisanje linije na standardni izlaz.
	 * 
	 * @param message
	 *            poruka koju �elimo zapisati
	 */
	public void write(String message);

	/**
	 * Metoda za pisanje linije na standarni ulaz uz dodani znak za novi red
	 * 
	 * @param message
	 *            poruka koju �elimo zapisati
	 */
	public void writeLn(String message);

	/**
	 * Metoda koja vra�a iterabilni objekt
	 * 
	 * @return iterabilni objekt
	 */
	public Iterable<ShellCommand> commands();

	/**
	 * Metoda za dohva�anje trenutne putanje
	 * 
	 * @return trenutna putanja
	 */
	public Path getCurrentPath();

	/**
	 * Metoda za postavljanje trenutne putanje
	 * 
	 * @param path
	 *            putanja koju �elimo postaviti kao trenutnu
	 */
	public void setCurrentPath(Path path);

}
