package hr.fer.oop.lab5.exams.commands;

import hr.fer.oop.lab5.exams.SheetData;
import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
import hr.fer.oop.lab5.shell.commands.AbstractCommand;

import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Razred predstavlja naredbu "print"
 * Ispisuje aktivan skup obrazaca.
 *
 * @author Filip Kujundzic
 */
public class PrintCommand extends AbstractCommand {
	 /**
     * Inicijalizacija komande
     * Kreira ime i opis
     */
    public PrintCommand() {
        super("print", "Display all active sheets info");
    }

	/**
	 * Naredba kojom se izvr�ava komanda. Prima dva argumenta.
	 * 
	 * @param environment
	 *            okru�enje kojim upravljamo ljuskom
	 * @param message
	 *           argumnet koji prima naredba (u ovom slu�aju null)
	 */
    @Override
    public CommandStatus execute(Environment environment, String parameters) {
        List<SheetData> sheets = LoadCommand.getSheets();
        Predicate<SheetData> test = sheet -> sheet.getGroup().equals("BLANK");

        if (sheets == null) {
            environment.writeLn("Please load sheets and answers first.");
            return CommandStatus.CONTINUE;
        }

        Collections.sort(sheets, (o1, o2) -> Double.compare(o2.getTotalScore().getAsDouble(), o1.getTotalScore().getAsDouble()));
        evaluateList(sheets.stream().filter(test.negate()), environment);
        evaluateList(sheets.stream().filter(test), environment);

        return CommandStatus.CONTINUE;
    }

    /**
     * Ispis streama
     *
     * @param stream      Stream
     * @param environment Okru�enje za rad s ljuskom
     */
    private void evaluateList(Stream<SheetData> stream, Environment environment) {
        stream.forEach(sheet -> {
            environment.write(sheet.getJmbag() + " [" + sheet.getGroup() + "]");

            sheet.getAnswers().forEach(answer -> {
                String sign = answer.equals("BLANK") ? "-" : answer;
                environment.write(" " + sign);
            });

            environment.write(" [Total: " + sheet.getTotalScore().getAsDouble() + "]");
            environment.writeLn("");
        });
    }
}
