package hr.fer.oop.lab5.shell;
/**
 * Enumeracija predstavlja status ljuske nakon izvr�enja pojedine naredbe.
 * CONTINUE predstavlja nastavak rada (�ekanje idu�e naredbe), dok EXIT predstavlja
 * zavr�etak rada s ljuskom.
 * @author Filip Kujundzic
 *
 */
public enum CommandStatus {
	
	CONTINUE, EXIT;
	
}
