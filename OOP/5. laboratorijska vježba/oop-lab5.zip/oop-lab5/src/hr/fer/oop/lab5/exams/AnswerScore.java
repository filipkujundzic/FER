package hr.fer.oop.lab5.exams;
/**
 * Razred predstavlja status ocjenjivanja te dodijeljene bodove za jedan
 * zadatak jednog studenta
 * @author Filip Kujundzic
 *
 */
public class AnswerScore {
	/**
	 * broj bodova na zadatku
	 */
    private double score;
    /**
     * status zadatka: to�an, neto�an ili neodgovoren
     */
    private AnswerStatus status;

    /**
     * Konstruktor kojim se postavljaju vrijednosti 
     * za broj bodova na zadatku i njegov status
     */
    public AnswerScore() {
        this.score = 0;
        this.status = AnswerStatus.UNANSWERED;
    }
    /**
     * Konstruktor kojim se postavljaju vrijednosti 
     * za broj bodova na zadatku i njegov status
     */
    public AnswerScore(double score, AnswerStatus status) {
        this.score = score;
        this.status = status;
    }

    /**
     * Metoda za dohvat bodova na zadatku
     * @return broj bodova na zadatku
     */
    public double getScore() {
        return score;
    }

    /**
     * Metoda za postavljanje bodova na zadatku
     * @param score broj bodova koji se �ele postaviti studentu 
     * za zadatak
     */
    public void setScore(double score) {
        this.score = score;
    }

    /**
     * Metoda za dohvat statusa zadatka
     * @return status zadatka
     */
    public AnswerStatus getStatus() {
        return status;
    }

    /**
     * Metoda za postavljanje statusa zadatka
     * @param status status koji se �eli postaviti studentu 
     * za zadatak
     */
    public void setStatus(AnswerStatus status) {
        this.status = status;
    }
}
