package hr.fer.oop.lab5.shell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import hr.fer.oop.lab5.shell.commands.CdCommand;
import hr.fer.oop.lab5.shell.commands.CopyCommand;
import hr.fer.oop.lab5.shell.commands.DateCommand;
import hr.fer.oop.lab5.shell.commands.FilterCommand;
import hr.fer.oop.lab5.shell.commands.HelpCommand;
import hr.fer.oop.lab5.shell.commands.PwdCommand;
import hr.fer.oop.lab5.shell.commands.QuitCommand;
import hr.fer.oop.lab5.shell.commands.TypeCommand;
import hr.fer.oop.lab5.shell.commands.XCopyCommand;
/**
 * Razred predstavlja ljusku koja (sli�no kao Command Prompt na Windowsima odnosno 
 * Bash na Linuxu) koja s korisnikom komunicira preko tipkovnice i ekrana.
 * @author Filip Kujundzic
 *
 */
public class MyShell {

	/**
	 * Mapa u koju pohranjujemo naziv komande (klju�)
	 * i tip podataka ShellCommand (vrijednost)
	 */
	private static final Map<String, ShellCommand> commands;

	/**
	 * stati�ki blok u kojem stvaramo primjerke naredbi ljuske
	 * i spremamo ih u mapu
	 */
	static {
		commands = new HashMap<>();
		ShellCommand[] cc = { 
				new HelpCommand(), 
				new QuitCommand(), 
				new CdCommand(), 
				new PwdCommand(),
				new DateCommand(),
				new TypeCommand(),
				new FilterCommand(),
				new CopyCommand(),
				new XCopyCommand()
			};
		for (ShellCommand c : cc) {
			commands.put(c.getCommandName().toUpperCase(), c);
		}
	}

	/**
	 * Stati�ka klasa koja implementira su�elje Environment
	 * Pomo�u nje upravljamo na�om ljuskom
	 *
	 */
	public static class EnvironmentImpl implements Environment {

		/**
		 * �ita� koji �ita znakove sa sistemskog ulaza
		 */
		private BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		/**
		 * Pisa� koji zapisuje znakove na sistemski izlaz
		 */
		private BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(System.out));
		/**
		 * Trenutna putanja s kojom ljuska radi
		 */
		private Path currentPath = Paths.get(".").toAbsolutePath().normalize();
		
		/**
		 * Metoda za �itanje jedne linije sa standardnog ulaza
		 */
		@Override
		public String readLine() {
			try {
				return reader.readLine();
			} catch (IOException e) {
				return null;
			}
		}

		/**
		 * Metoda za pisanje jedne linije na standardni izlaz
		 */
		@Override
		public void write(String line) {

			try {
				writer.write(line);
				writer.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		
		/**
		 * Metoda za pisanje jedne linije na standardni izlaz
		 * (dodaje i znak za novi red na kraju linije)
		 */
		@Override
		public void writeLn(String line) {

			line += "\n";
			try {
				writer.write(line);
				writer.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		/**
		 * Iterabilni objekt kako bi mogli prolaziti po komandama
		 */
		@Override
		public Iterable<ShellCommand> commands() {
			return commands.values();

		}

		/**
		 * Metoda za dohvat trenutne putanje
		 */
		@Override
		public Path getCurrentPath() {
			return currentPath;
		}

		/**
		 * Metoda za postavljanje trenutne putanje
		 */
		@Override
		public void setCurrentPath(Path path) {
			currentPath = getCurrentPath().resolve(path);
		}

	}

	/**
	 * Primjerak razreda EnvironmentImpl
	 */
	public static Environment environment = new EnvironmentImpl();
	/**
	 * Metoda main za rad s ljuskom.
	 * @param args Argumenti koji se dobiju preko komandne linije
	 * @throws IOException Iznimka u slu�aju pogre�nog �itanja/pisanja datoteke
	 */
	public static void main(String[] args) throws IOException {
		environment.writeLn("Welcome to MyShell! You may enter commands.");
		while (true) {
			environment.write("$" + environment.getCurrentPath().getFileName() + "> ");
			String line = environment.readLine();
			String[] parts = line.split(" ",2); 
			String cmd = parts[0];
			String arg;
			try{
				arg = parts[1];
			}catch(ArrayIndexOutOfBoundsException e){
				arg = null;
			}
			ShellCommand shellCommand = commands.get(cmd.toUpperCase());
			if (shellCommand == null) {
				environment.writeLn("Unknown command!");
				continue;
			}
			if (shellCommand.execute(environment, arg) == CommandStatus.EXIT)
				break;
		}
		environment.writeLn("Thank you for using this shell. Goodbye!");
	}
}
