package hr.fer.oop.lab5.exams;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import hr.fer.oop.lab5.exams.commands.FilterCommand;
import hr.fer.oop.lab5.exams.commands.LoadCommand;
import hr.fer.oop.lab5.exams.commands.PrintCommand;
import hr.fer.oop.lab5.exams.commands.ProblemStatisticsCommand;
import hr.fer.oop.lab5.exams.commands.ResetCommand;
import hr.fer.oop.lab5.exams.commands.StatisticsCommand;
import hr.fer.oop.lab5.exams.commands.StudentResultsCommand;
import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
import hr.fer.oop.lab5.shell.ShellCommand;
import hr.fer.oop.lab5.shell.commands.HelpCommand;
import hr.fer.oop.lab5.shell.commands.QuitCommand;

/**
 * Ljuska za upravljanje ispitima.
 *
 * @author Filip Kujundzic
 */
public class ExamsShell {
    /**
     * Mapa komandi
     * Sadr�i ime komande i komandu kao objekt
     */
    private static Map<String, ShellCommand> commands;

    /**
     * Sve komande pohranjene u polju komandi
     */
    private static ShellCommand[] allCommands = {
            new LoadCommand(),
            new QuitCommand(),
            new FilterCommand(),
            new ResetCommand(),
            new ProblemStatisticsCommand(),
            new StatisticsCommand(),
            new HelpCommand(),
            new PrintCommand(),
            new StudentResultsCommand()
    };

    public static class EnvironmentImpl implements Environment {

		/**
		 * �ita� koji �ita znakove sa sistemskog ulaza
		 */
		private BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		/**
		 * Pisa� koji zapisuje znakove na sistemski izlaz
		 */
		private BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(System.out));
		/**
		 * Trenutna putanja s kojom ljuska radi
		 */
		private Path currentPath = Paths.get(".").toAbsolutePath().normalize();
		
		/**
		 * Metoda za �itanje jedne linije sa standardnog ulaza
		 */
		@Override
		public String readLine() {
			try {
				return reader.readLine();
			} catch (IOException e) {
				return null;
			}
		}

		/**
		 * Metoda za pisanje jedne linije na standardni izlaz
		 */
		@Override
		public void write(String line) {

			try {
				writer.write(line);
				writer.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		/**
		 * Metoda za pisanje jedne linije na standardni izlaz
		 * (dodaje i znak za novi red na kraju linije)
		 */
		@Override
		public void writeLn(String line) {

			line += "\n";
			try {
				writer.write(line);
				writer.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		/**
		 * Iterabilni objekt kako bi mogli prolaziti po komandama
		 */
		@Override
		public Iterable<ShellCommand> commands() {
			return commands.values();

		}

		/**
		 * Metoda za dohvat trenutne putanje
		 */
		@Override
		public Path getCurrentPath() {
			return currentPath;
		}

		/**
		 * Metoda za postavljanje trenutne putanje
		 */
		@Override
		public void setCurrentPath(Path path) {
			currentPath = getCurrentPath().resolve(path);
		}
	}  
    
    /**
     * Okru�enje ljuske
     */
    public static Environment environment = new EnvironmentImpl();

    static {
        commands = new HashMap<>();

        for (ShellCommand c : allCommands) {
            commands.put(c.getCommandName().toUpperCase(), c);
        }
    }

    /**
     * Omogu�uje korisniku interakciju sa okru�enjem ljuske
     *
     * @param args argumenti komandne linije
     * @throws IOException iznimka u slu�aju pogre�aka s
     * �itanjem/pisanjem 
     */
    public static void main(String[] args) throws IOException {
       
    	environment.writeLn("Welcome to ExamShell! You may enter commands.");
        while (true) {
        	environment.write("$> ");
            // �itanje linije
            String line = environment.readLine();
            String[] result = line.split(" ", 2);
            String command = result[0];
            String arg = result.length > 1 ? result[1] : "";

            // Dohavat komande
            ShellCommand shellCommand = commands.get(command.toUpperCase());

            // Slu�aj nepostojanja komande
            if (shellCommand == null) {
                environment.writeLn("Unknown command!");
                continue;
            }

            if (shellCommand.execute(environment, arg) == CommandStatus.EXIT) {
                break;
            }
            
        }
        environment.writeLn("Thank you for using this shell. Goodbye!");
    }
}
