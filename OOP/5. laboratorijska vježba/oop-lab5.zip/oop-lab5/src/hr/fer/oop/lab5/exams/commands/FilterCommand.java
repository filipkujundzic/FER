package hr.fer.oop.lab5.exams.commands;

import hr.fer.oop.lab5.exams.AnswerStatus;
import hr.fer.oop.lab5.exams.SheetData;
import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
import hr.fer.oop.lab5.shell.commands.AbstractCommand;

import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Razred koji rukuje naredbom "filter"
 * Omogu�uje filtriranje po obrascima
 *
 * @author Filip Kujund�i�
 */
public class FilterCommand extends AbstractCommand {
    /**
     * Inicijalizacija naredbe
     * Stvara ime komande i njen opis
     */
    public FilterCommand() {
        super("filter", "Filter student sheets");
    }

    /**
     * Naredba za izvr�avanje komande
     * @param environment okru�enje za upravljanje ljuskom 
     * @param parameters argumenti komande
     */
    @Override
    public CommandStatus execute(Environment environment, String parameters) {
        List<SheetData> sheets = LoadCommand.getSheets();
        Map<String, String[]> answers = LoadCommand.getAnswers();
        FilterCommandHandler handler = new FilterCommandHandler(sheets, answers, environment);
        Matcher matcher;

        if (parameters.isEmpty()) {
            return CommandStatus.CONTINUE;
        }

        if (sheets == null || answers == null) {
            environment.writeLn("Please load sheets and answers first.");
            return CommandStatus.CONTINUE;
        }

        // graded
        if (parameters.equals("graded")) {
            handler.graded();
        }
        // !graded
        else if (parameters.equals("!graded")) {
            handler.notGraded();
        }
        // group=X
        else if ((matcher = Pattern.compile("group=([a-zA-Z]+)").matcher(parameters)).matches()) {
            handler.group(matcher.group(1));
        }
        // score(<|>)=X
        else if ((matcher = Pattern.compile("score(<|>)=([0-9]+)").matcher(parameters)).matches()) {
            handler.score(matcher.group(1), matcher.group(2));
        }
        // status X Y
        else if ((matcher = Pattern.compile("status ([0-9]+) (?i)(correct|incorrect|unanswered)").matcher(parameters)).matches()) {
            handler.status(matcher.group(1), matcher.group(2));
        }
        // answer X Y
        else if ((matcher = Pattern.compile("answer ([0-9]+) ([a-zA-Z]+)").matcher(parameters)).matches()) {
            handler.answer(matcher.group(1), matcher.group(2));
        }

        return CommandStatus.CONTINUE;
    }

    /**
     * Klasa koja upravlja filterima
     * Svaka metoda predstavlja jedan filter.
     *
     * @author Filip Kujundzic
     */
    class FilterCommandHandler {
        private List<SheetData> sheets;
        private Map<String, String[]> answers;
        private Environment environment;

        public FilterCommandHandler(List<SheetData> sheets, Map<String, String[]> answers, Environment environment) {
            this.sheets = sheets;
            this.answers = answers;
            this.environment = environment;
        }

        /**
         * Omogu�uje "graded" filter
         */
        public void graded() {
            evaluate(sheets.stream().filter(sheet -> !sheet.getGroup().equals("BLANK") && answers.containsKey(sheet.getGroup())));
        }

        /**
         * Omogu�uje "status" filter
         *
         * @param problem      Broj zadatka
         * @param answerStatus status (correct, incorrect, unanswered)
         */
        public void status(String problem, String answerStatus) {
            AnswerStatus status;
            final int task = Integer.parseInt(problem);

            switch (answerStatus) {
                case "correct":
                    status = AnswerStatus.ANSWERED_CORRECT;
                    break;
                case "incorrect":
                    status = AnswerStatus.ANSWERED_INCORRECT;
                    break;
                default:
                    status = AnswerStatus.UNANSWERED;
                    break;
            }

            evaluate(sheets.stream()
                    .filter(sheet -> !sheet.getGroup().equals("BLANK") && sheet.getAnswerScores().get(task - 1).getStatus().equals(status)));
        }

        /**
         * Omogu�uje "answer" filter
         *
         * @param problem      Broj zadatka
         * @param searchAnswer Odgovor prema kojem se filtrira
         */
        public void answer(String problem, String searchAnswer) {
            int task = Integer.parseInt(problem);
            evaluate(sheets.stream().filter(sheet -> sheet.getAnswers().get(task - 1).equals(searchAnswer)));
        }

        /**
         * Omogu�uje "score" filter
         *
         * @param operation   <= ili >=
         * @param scoreString Broj bodova koji �elimo postaviti kao limit
         */
        public void score(String operation, String scoreString) {
            Double score = Double.parseDouble(scoreString);

            Predicate<SheetData> test = operation.equals("<") ?
                    sheet -> sheet.getTotalScore().getAsDouble() <= score :
                    sheet -> sheet.getTotalScore().getAsDouble() >= score;

            evaluate(sheets.stream().filter(test));
        }

        /**
         * Omogu�uje "group" filter
         *
         * @param group grupa
         */
        public void group(String group) {
            if (!answers.containsKey(group)) {
                environment.writeLn("There are no correct answers specified for this group.");
            } else {
                evaluate(sheets.stream().filter(sheet -> sheet.getGroup().equals(group)));
            }
        }

        /**
         * Omogu�uje "!graded" filter
         */
        public void notGraded() {
            evaluate(sheets.stream().filter(sheet -> sheet.getGroup().equals("BLANK") || !answers.containsKey(sheet.getGroup())));
        }

        /**
         * Postavlja obrasce i prikazuje poruku
         *
         * @param stream Stream koji treba obraditi
         */
        @SuppressWarnings({ "rawtypes", "unchecked" })
		private void evaluate(Stream stream) {
            LoadCommand.setSheets((List<SheetData>)stream.collect(Collectors.toList()));

            environment.writeLn("Results filtered: " + LoadCommand.getSheets().size());
        }
    }

}