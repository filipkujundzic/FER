package hr.fer.oop.lab5.shell;

/**
 * Su�elje definira naredbe kojima upravljamo ljuskom
 * 
 * @author Filip Kujundzic
 */
public interface ShellCommand {

	/**
	 * Metoda za dohvat imena naredbe
	 * 
	 * @return ime naredbe u obliku stringa
	 */
	public String getCommandName();

	/**
	 * Metoda za dohvat opisa komande
	 * 
	 * @return opis komande u obliku stringa
	 */
	public String getCommandDescription();

	/**
	 * Metoda za izvr�avanje naredbe u ljusci.
	 * 
	 * @param executioner
	 *            okru�enje za rad s ljuskom
	 * @param message
	 *            argument naredbe
	 * @return status komande kojim se odre�uje daljnje pona�anje ljuske
	 */
	public CommandStatus execute(Environment executioner, String message);

}
