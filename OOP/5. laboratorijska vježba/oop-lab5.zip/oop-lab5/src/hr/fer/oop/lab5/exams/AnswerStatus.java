package hr.fer.oop.lab5.exams;

/**
 * Enumeracija koja predstavlja status svakog odgovora.
 * Odgovor mo�e biti to�an, neto�an ili neodgovoren.
 */
public enum AnswerStatus {
    /**
     * Neodgovoren
     */
    UNANSWERED("Unanswered"),

    /**
     * To�an odgovor
     */
    ANSWERED_CORRECT("Answered correctly"),

    /**
     * Neto�an odgovor
     */
    ANSWERED_INCORRECT("Answered incorrectly");

    private String label;

    /**
     * Inicijalizacija oznake
     *
     * @param label oznaka
     */
    AnswerStatus(String label) {
        this.label = label;
    }

    /**
     * Metoda za pretvaranje oznake u string
     */
    @Override
    public String toString() {
        return label;
    }
}
