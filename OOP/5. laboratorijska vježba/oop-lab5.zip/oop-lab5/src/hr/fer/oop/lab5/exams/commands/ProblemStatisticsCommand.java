package hr.fer.oop.lab5.exams.commands;

import hr.fer.oop.lab5.exams.SheetData;
import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
import hr.fer.oop.lab5.shell.commands.AbstractCommand;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Razred predstavlja naredbu "problem-statistics"
 * Ra�una statistiku svakog zadatka u ispitu
 *
 * @author Filip Kujundzic
 */
public class ProblemStatisticsCommand extends AbstractCommand {
	 /**
     * Inicijalizacija komande
     * Kreira ime i opis
     */
    public ProblemStatisticsCommand() {
        super("problem-statistics", "Calculate the statistics of each problem");
    }

    /**
	 * Naredba kojom se izvr�ava komanda. Prima dva argumenta.
	 * 
	 * @param environment
	 *            okru�enje kojim upravljamo ljuskom
	 * @param parameters
	 *           argumnet koji prima naredba (u ovom slu�aju null)
	 */
    @Override
    public CommandStatus execute(Environment environment, String parameters) {
        List<SheetData> sheets = LoadCommand.getSheets();
        Map<String, String[]> answers = LoadCommand.getAnswers();
        Map<String, Integer> tempAnswers = new HashMap<>();

        if (sheets == null || answers == null) {
            environment.writeLn("Please load sheets and answers first.");
            return CommandStatus.CONTINUE;
        }

        // Dohvat broja zadataka
        int numberOfProblems = answers.get(sheets.get(0).getGroup()).length;

        for (int i = 1; i <= numberOfProblems; i++) {
            environment.writeLn("Problem " + i + ".");

            for (SheetData sheet : sheets) {
                String currentAnswer = sheet.getAnswers().get(i - 1);

                int add;

                if (tempAnswers.containsKey(currentAnswer)) {
                    int answerCount = tempAnswers.get(currentAnswer);
                    add = ++answerCount;
                } else {
                    add = 1;
                }

                tempAnswers.put(currentAnswer, add);
            }

            tempAnswers.forEach((key, value) -> {
                environment.writeLn("\t" + key + ": " + value);
            });

            tempAnswers.clear();
            environment.writeLn("");
        }

        return CommandStatus.CONTINUE;
    }
}
