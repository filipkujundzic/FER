package hr.fer.oop.lab5.exams.commands;

import hr.fer.oop.lab5.exams.AnswerScore;
import hr.fer.oop.lab5.exams.SheetData;
import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
import hr.fer.oop.lab5.shell.commands.AbstractCommand;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Razred predstavlja naredbu "student-result"
 * Ispisuje statistiku studenta kojeg tra�imo po njegovom JMBAG-u
 *
 * @author Filip Kujundzic
 */
public class StudentResultsCommand extends AbstractCommand {
	  /**
     * Inicijalizacija naredbe
     * Stvara ime komande i njen opis
     */
	public StudentResultsCommand() {
        super("student-result", "Display statistics for a student");
    }

	/**
	 * Naredba kojom se izvr�ava komanda. Prima dva argumenta.
	 * 
	 * @param environment
	 *            okru�enje kojim upravljamo ljuskom
	 * @param message
	 *           argumnet koji prima naredba (u ovom slu�aju null)
	 */
    @Override
    public CommandStatus execute(Environment environment, String jmbag) {
        List<SheetData> sheets = LoadCommand.getInitialSheets();

        if (sheets == null) {
            environment.writeLn("Please load sheets and answers first.");
            return CommandStatus.CONTINUE;
        }

        Map<String, SheetData> studentsByJmbag = new HashMap<>();
        sheets.forEach(sheet -> studentsByJmbag.put(sheet.getJmbag(), sheet));
        SheetData info = studentsByJmbag.get(jmbag);

        if (info == null) {
            environment.writeLn("Student with the ID of " + jmbag + " does not exist in the database.");
            return CommandStatus.CONTINUE;
        }

        environment.writeLn("Student ID: " + jmbag);
        environment.writeLn("Total score: " + info.getTotalScore().getAsDouble());
        environment.writeLn("Group: " + info.getGroup());
        environment.writeLn("Answers: ");

        int[] i = {0};

        if (info.getGroup().equals("BLANK")) {
            environment.writeLn("\t\tStudent with the ID of " + jmbag + " did not specify a group.");
            return CommandStatus.CONTINUE;
        }

        info.getAnswers().forEach(answer -> {
            environment.write("\t\t" + (!answer.equals("BLANK") ? answer : "-") + " / ");

            AnswerScore score = info.getAnswerScores().get(i[0]++);
            String sign;

            switch (score.getStatus()) {
                case ANSWERED_CORRECT:
                    sign = "T";
                    break;
                case ANSWERED_INCORRECT:
                    sign = "N";
                    break;
                default:
                    sign = "-";
            }

            environment.write(sign + " (" + score.getScore() + ")");
            environment.writeLn("");
        });

        return CommandStatus.CONTINUE;
    }
}
