package hr.fer.oop.lab5.exams;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;

/**
 * Razred predstavlja ukupne podatke o ispitu jednog studenta.
 * Svaki primjerak razreda ima: jmbag, grupu, odgovore studenta, bodove i ukupne bodove
 * @author Filip Kujund�i�
 */
public class SheetData {
    /**
     * Stuentov jmbag
     */
    private String jmbag;

    /**
     * Studentova grupa na ispitu
     */
    private String group;

    /**
     * Studentovi odgovori
     */
    private List<String> answers = new ArrayList<>();

    /**
     * Broj bodova za svaki zadatak na ispitu
     */
    private List<AnswerScore> answerScores = new ArrayList<>();

    /**
     * Ukupni broj bodova na ispitu
     */
    private OptionalDouble totalScore = OptionalDouble.empty();

    /**
     * Inicijalizacija ukupnih podataka o ispitu sa studentovim jmbagom, 
     * studentovom grupom i studentovim odgovorima
     * @param jmbag Studentov jmbag
     * @param group Oznaka grupe
     * @param answers Studentovi odgovori
     */
    public SheetData(String jmbag, String group, List<String> answers) {
        this.jmbag = jmbag;
        this.group = group;
        this.answers = answers;
        this.totalScore = OptionalDouble.of(0);
    }

    /**
     * Metoda za postavljanje ukupnog broja bodova
     * @param totalScore ukupni broj bodova
     */
    public void setTotalScore(OptionalDouble totalScore) {
        this.totalScore = totalScore;
    }

    /**
     * Metoda za dohva�anje studentovog jmbag-a
     * @return studentov jmbag
     */
    public String getJmbag() {
        return jmbag;
    }

    /**
     * Metoda za dohva�anje studentove grupe
     * @return studentova grupa
     */
    public String getGroup() {
        return group;
    }
    /**
     * Metoda za dohvat studentovih odgovora
     * @return lista sa studentovim odgovorima
     */
    public List<String> getAnswers() {
        return answers;
    }

    /**
     * Metoda za dohvat to�nih odgovora studentove grupe na ispitu
     * @return lista sa to�nim odgovorima grupe
     */
    public List<AnswerScore> getAnswerScores() {
        return answerScores;
    }

    /**
     * Metoda za dohvat ukupnog broja bodova ostvarenog na ispitu
     * @return OptionalDouble vrijednost 
     */
    public OptionalDouble getTotalScore() {
        return totalScore;
    }
}
