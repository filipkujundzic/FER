package hr.fer.oop.lab5.shell.commands;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
/**
 * Razred predstavlja naredbu xcopy
 * 
 * @author Filip Kujundzic
 *
 */
public class XCopyCommand extends AbstractCommand{

	/**
	 * Konstruktor naredbe xcopy. Naslje�uje ime komande i njen opis.
	 */
	public XCopyCommand() {
		super("xcopy", "Copies files and directories, including subdirectories.");
	}

	/**
	 * Naredba kojom se izvr�ava komanda. Prima dva argumenta.
	 * 
	 * @param executioner
	 *            okru�enje kojim upravljamo ljuskom
	 * @param message
	 *            argument koji prima naredba
	 */
	@Override
	public CommandStatus execute(Environment executioner, String message) {
		String array[] = message.split(" ", 2);
		
		try {
			Files.walkFileTree(Paths.get(array[0]).toAbsolutePath(), new LookInAllDirectories(Paths.get(array[1]).toAbsolutePath()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return CommandStatus.CONTINUE;
	}
	
	private static class LookInAllDirectories implements FileVisitor<Path>{
		private Path dest;
		
		public LookInAllDirectories(Path dest) {
			this.dest = dest;
		}
		
		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc)
				throws IOException {
			dest = dir.getParent();
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult preVisitDirectory(Path dir,BasicFileAttributes attrs) throws IOException {
			File novadest = new File(dest.toString() + "\\" + dir.getFileName());
			novadest.mkdir();
			dest = novadest.toPath();
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
				throws IOException {
			BinaryStreamCopy.BinaryCopy(file.toAbsolutePath().toString(), dest.toString() + "\\" + file.getFileName());
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc)
				throws IOException {
			return FileVisitResult.CONTINUE;
		}
		
	}
}
