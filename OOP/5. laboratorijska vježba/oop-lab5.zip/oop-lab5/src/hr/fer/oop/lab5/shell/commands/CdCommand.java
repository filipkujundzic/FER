package hr.fer.oop.lab5.shell.commands;

import java.nio.file.Path;

import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;

/**
 * Razred predstavlja komandu cd za ljusku
 * 
 * @author Filip Kujundzic
 *
 */
public class CdCommand extends AbstractCommand {
	/**
	 * Konstruktr naredbe cd; naslje�uje ime komande i njen opis
	 */
	public CdCommand() {
		super("cd", "changes the directory");
	}

	/**
	 * Naredba za izvr�avanje komande
	 * 
	 * @param executioner
	 *            okru�enje za rad s ljuskom
	 * @param message
	 *            argument koji predajemo naredbi
	 */
	@Override
	public CommandStatus execute(Environment executioner, String message) {

		if (message.equals("..")) {
			Path novi = executioner.getCurrentPath().getParent().normalize();
			executioner.setCurrentPath(novi);
		} else {
			Path novi = executioner.getCurrentPath().resolve(message);
			executioner.setCurrentPath(novi);
		}

		return CommandStatus.CONTINUE;
	}

}
