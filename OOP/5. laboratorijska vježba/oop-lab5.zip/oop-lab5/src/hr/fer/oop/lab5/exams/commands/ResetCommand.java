package hr.fer.oop.lab5.exams.commands;

import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
import hr.fer.oop.lab5.shell.commands.AbstractCommand;

/**
 * Razred predstavlja naredbu "reset"
 * Resetira sve filter operacije
 *
 * @author Filip Kujundzic
 */
public class ResetCommand extends AbstractCommand {
	 /**
     * Inicijalizacija komande
     * Kreira ime i opis
     */
    public ResetCommand() {
        super("reset", "Remove all filters");
    }

    /**
	 * Naredba kojom se izvr�ava komanda. Prima dva argumenta.
	 * 
	 * @param environment
	 *            okru�enje kojim upravljamo ljuskom
	 * @param parameters
	 *           argumnet koji prima naredba (u ovom slu�aju null)
	 */
    @Override
    public CommandStatus execute(Environment environment, String parameters) {
        LoadCommand.reset();
        environment.writeLn("Everything has been reset. Results after reset: " + LoadCommand.getSheets().size());

        return CommandStatus.CONTINUE;
    }
}
