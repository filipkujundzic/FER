package hr.fer.oop.lab5.shell.commands;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Razred implementira pomo�nu metodu za izvo�enje kopiranja pomo�u binarnih
 * tokova
 * 
 * @author Filip Kujundzic
 *
 */
public class BinaryStreamCopy {

	/**
	 * Konstruktor razreda
	 */
	public BinaryStreamCopy() {
	}

	/**
	 * Metoda kojom se izvodi kopiranje
	 * 
	 * @param source
	 *            izvor iz kojeg �elimo kopirati
	 * @param destination
	 *            destinacija u koju �elimo kopirati
	 * @throws IOException
	 *             iznimka koja se javlja u slu�aju problema s �itanjem/pisanjem
	 */
	public static void BinaryCopy(String source, String destination) throws IOException {
		InputStream inputStream = null;
		OutputStream outputStream = null;

		try {
			inputStream = new FileInputStream(source);
			outputStream = new FileOutputStream(destination);

			byte[] buffer = new byte[1024];

			int length;
			while ((length = inputStream.read(buffer)) != -1) {
				outputStream.write(buffer, 0, length);
			}
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
			if (outputStream != null) {
				outputStream.close();
			}
		}
	}
}
