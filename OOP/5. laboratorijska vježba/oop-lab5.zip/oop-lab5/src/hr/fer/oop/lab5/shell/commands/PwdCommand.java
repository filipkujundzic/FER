package hr.fer.oop.lab5.shell.commands;

import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
/**
 * Razred predstavlja komandu pwd za ljusku
 * @author Filip Kujundzic
 *
 */
public class PwdCommand extends AbstractCommand{

	/**
	 * Konstruktr naredbe pwd; naslje�uje ime komande i njen opis
	 */
	public PwdCommand() {
		super("pwd","Writes the full pathname of the current working directory.");
	}
	
	/**
	 * Naredba za izvr�avanje komande
	 * 
	 * @param executioner
	 *            okru�enje za rad s ljuskom
	 * @param message
	 *            argument koji predajemo naredbi
	 */
	@Override
	public CommandStatus execute(Environment executioner, String message) {
		System.out.println(executioner.getCurrentPath());
		return CommandStatus.CONTINUE;
	}
}
