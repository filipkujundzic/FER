package hr.fer.oop.lab5.shell.commands;

import hr.fer.oop.lab5.shell.ShellCommand;

/**
 * Razred definira mehanizam �uvanja imena i opisa tako da to ne mora svaka
 * naredba kopirati.
 * 
 * @author Filip Kujundzic
 *
 */
public abstract class AbstractCommand implements ShellCommand {

	/**
	 * ime komande
	 */
	private final String commandName;
	/**
	 * opis komande
	 */
	private final String commandDescription;

	/**
	 * Konstruktor razreda Abstract command
	 * 
	 * @param commandName
	 *            ime komande
	 * @param commandDescription
	 *            opis komande
	 */
	public AbstractCommand(String commandName, String commandDescription) {
		this.commandName = commandName;
		this.commandDescription = commandDescription;
	}

	/**
	 * Metoda za dohva�anje imena komande
	 */
	@Override
	public String getCommandName() {
		return commandName;
	}

	/**
	 * Metoda za dohva�anje opisa komande
	 */
	@Override
	public String getCommandDescription() {
		return commandDescription;
	}
}
