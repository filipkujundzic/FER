package hr.fer.oop.lab5.shell.commands;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.regex.Pattern;

import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;

/**
 * Razred predstavlja komandu filter za ljusku
 * 
 * @author Filip Kujundzic
 *
 */
public class FilterCommand extends AbstractCommand {

	/**
	 * Konstruktr naredbe filter; naslje�uje ime komande i njen opis
	 */
	public FilterCommand() {
		super("filter", "Searches the current directory and all subdirectories for a pattern.");
	}

	/**
	 * Naredba za izvr�avanje komande
	 * 
	 * @param executioner
	 *            okru�enje za rad s ljuskom
	 * @param message
	 *            argument koji predajemo naredbi
	 */
	@Override
	public CommandStatus execute(Environment executioner, String message) {
		/**
		 * zastavica u koju spremamo podatak da li uneseni argument sadr�i
		 * ekstenziju
		 */
		boolean containsExtension = false;
		
		if (message == null) {
			message = "";
		}
		for (char s : message.toCharArray()) {
			if (s == '.' && s++ != '\0') {
				containsExtension = true;
			}
		}
		if (containsExtension == false) {
			System.out.println("File doesn't have extension!");
			return CommandStatus.CONTINUE;
		}
		StringBuilder builder = new StringBuilder();

		for (char c : message.toCharArray()) {
			if (c == '.') {
				builder.append("\\");
			} else if (c == '*') {
				builder.append(".");
			}
			builder.append(c);
		}

		Pattern p = Pattern.compile(builder.toString(), Pattern.CASE_INSENSITIVE);

		LookInAllDirectories l = new LookInAllDirectories(p);
		try {
			Files.walkFileTree(executioner.getCurrentPath(), l);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return CommandStatus.CONTINUE;
	}

	private static class LookInAllDirectories implements FileVisitor<Path> {
		private Pattern p;

		public LookInAllDirectories(Pattern p) {
			this.p = p;
		}

		@Override
		public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
			if (p.matcher(file.getFileName().toString()).matches()) {
				System.out.println(file);
			}
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
			return FileVisitResult.TERMINATE;
		}

		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
			return FileVisitResult.CONTINUE;
		}

	}
}
