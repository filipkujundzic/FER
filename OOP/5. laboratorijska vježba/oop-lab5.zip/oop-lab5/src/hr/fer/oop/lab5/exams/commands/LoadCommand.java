package hr.fer.oop.lab5.exams.commands;

import hr.fer.oop.lab5.exams.AnswerScore;
import hr.fer.oop.lab5.exams.AnswerStatus;
import hr.fer.oop.lab5.exams.SheetData;
import hr.fer.oop.lab5.exams.SheetDataLoader;
import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
import hr.fer.oop.lab5.shell.commands.AbstractCommand;

import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;

/**
 * Razred predstavlja naredbu "load"
 * U�itava obrasce i odgovore u stati�ke varijable i ocjenjuje studente.
 *
 * @author Filip Kujundzic
 */
public class LoadCommand extends AbstractCommand {
    private static List<SheetData> initial = null;
    private static List<SheetData> sheets = null;
    private static Map<String, String[]> answerSheet = null;
    private Environment environment;

    /**
     * Inicijalizacija komande
     * Kreira ime i opis
     */
    public LoadCommand() {
        super("load", "Load sheet data and correct answers");
    }

	/**
	 * Naredba kojom se izvr�ava komanda. Prima dva argumenta.
	 * 
	 * @param environment
	 *            okru�enje kojim upravljamo ljuskom
	 * @param parameters
	 *           argumnet koji prima naredba (u ovom slu�aju null)
	 */
    @Override
    public CommandStatus execute(Environment environment, String parameters) {
        this.environment = environment;
        String[] params = parameters.split(" ", 5);

        if (params.length != 5) {
            environment.writeLn("You did not specify 5 parameters.");
            return CommandStatus.CONTINUE;
        }

        // Broj bodova za svaki to�an odgovor
        Double correctPoints = Double.parseDouble(params[2]);

        // Broj bodova za svaki neto�an odgovor
        Double wrongPoints = Double.parseDouble(params[3]);

        // Broj bodova za svaki neodgovoreni odgovor
        Double unansweredPoints = Double.parseDouble(params[4]);

        // U�itavanje svih obrazaca
        sheets = initial = SheetDataLoader.loadSheets(Paths.get(params[0]), environment);

        // U�itavanje to�nih odgovora
        answerSheet = SheetDataLoader.loadCorrectAnswers(Paths.get(params[1]), environment);

        filterBlank();
        filterNoAnswers();
        handle(correctPoints, wrongPoints, unansweredPoints);

        return CommandStatus.CONTINUE;
    }
    
    /**
     * Metoda kojom se provodi ocjenjivanje
     * @param correctPoints broj bodova za to�an odgovor
     * @param wrongPoints broj bodova za neto�an odgovor
     * @param unansweredPoints broj bodova za neodgovoren odgovor
     */
    private void handle(Double correctPoints, Double wrongPoints, Double unansweredPoints) {
        sheets.stream()
                .filter(x -> !x.getGroup().equals("BLANK") && answerSheet.containsKey(x.getGroup()))
                .forEach(sheet -> {
                    String[] answers = answerSheet.get(sheet.getGroup());

                    List<AnswerScore> answerScores = sheet.getAnswerScores();
                    List<String> answer = sheet.getAnswers();

                    double currentScore = 0;
                    double score = sheet.getTotalScore().getAsDouble();
                    int item = 0;
                    AnswerStatus status;

                    while (item != answer.size()) {
                        if (answer.get(item).equals(answers[item])) {
                            currentScore = correctPoints;
                            status = AnswerStatus.ANSWERED_CORRECT;
                        } else if (answer.get(item).equals("BLANK")) {
                            currentScore = unansweredPoints;
                            status = AnswerStatus.UNANSWERED;
                        } else {
                            currentScore = wrongPoints;
                            status = AnswerStatus.ANSWERED_INCORRECT;
                        }
                        score += currentScore;
                        answerScores.add(new AnswerScore(currentScore, status));
                        item++;
                    }

                    sheet.setTotalScore(OptionalDouble.of(score));

                });
    }
    /**
     * Metoda za filtriranje studenata koji nisu ozna�ili grupu
     */
    private void filterBlank() {
        sheets.stream()
                .filter(x -> x.getGroup().equals("BLANK"))
                .forEach(x -> environment.writeLn("Student " + x.getJmbag() + " did not specify a group on his sheet."));
    }
    /**
     * Metoda za filtriranje studenata koji su ozna�ili nepostoje�u grupu
     */
    private void filterNoAnswers() {
        sheets.stream()
                .filter(x -> !x.getGroup().equals("BLANK") && !answerSheet.containsKey(x.getGroup()))
                .forEach(x -> environment.writeLn("Student " + x.getJmbag() + " has specified a group that has no correct answers supplied."));
    }

    /**
     * Metoda za dohvat obrazaca
     * @return lista s obrascima
     */
    public static List<SheetData> getSheets() {
        return sheets;
    }

    /**
     * Metoda za dohvat po�etnih obrazaca
     * @return lista po�etnih obrazaca
     */
    public static List<SheetData> getInitialSheets() {
        return initial;
    }
    
    /**
     * Metoda za postavljanje obrazaca
     * @param data obrasci koje �elimo postaviti
     */
    public static void setSheets(List<SheetData> data) {
        sheets = data;
    }

    /**
     * Metoda za dohvat odgovora
     * @return mapa s odgovorima
     */
    public static Map<String, String[]> getAnswers() {
        return answerSheet;
    }
    
    /**
     * Metoda za postavljanje to�nih odgovora
     * @param data to�ni odgovori koje �elimo postaviti
     */
    public static void setAnswers(Map<String, String[]> data) {
        answerSheet = data;
    }

    /**
     * Metoda za povratak skupa obrazaca u po�etno stanje (prije filtriranja)
     */
    public static void reset() {
        setSheets(initial);
    }
}
