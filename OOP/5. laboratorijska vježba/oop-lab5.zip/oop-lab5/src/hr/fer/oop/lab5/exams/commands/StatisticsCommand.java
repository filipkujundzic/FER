package hr.fer.oop.lab5.exams.commands;

import hr.fer.oop.lab5.exams.AnswerStatus;
import hr.fer.oop.lab5.exams.SheetData;
import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
import hr.fer.oop.lab5.shell.commands.AbstractCommand;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Razred predstavlja naredbu "statistics"
 * Ra�una statistiku svakog zadatka u ispitu
 *
 * @author Filip Kujundzic
 */
public class StatisticsCommand extends AbstractCommand {
	 /**
     * Inicijalizacija komande
     * Kreira ime i opis
     */
    public StatisticsCommand() {
        super("statistics", "Calculate the statistics of all active sheets");
    }

    /**
   	 * Naredba kojom se izvr�ava komanda. Prima dva argumenta.
   	 * 
   	 * @param environment
   	 *            okru�enje kojim upravljamo ljuskom
   	 * @param parameters
   	 *           argumnet koji prima naredba (u ovom slu�aju null)
   	 */
    @SuppressWarnings("unused")
	@Override
    public CommandStatus execute(Environment environment, String parameters) {
        List<SheetData> sheets = LoadCommand.getSheets();
        Map<String, String[]> answers = LoadCommand.getAnswers();

        if (sheets == null || answers == null) {
            environment.writeLn("Please load sheets and answers first.");
            return CommandStatus.CONTINUE;
        }

        int i = 0;

        for (String s : answers.get(sheets.get(0).getGroup())) {
            int iter = ++i;

            environment.writeLn("Problem " + i + ".");

            Map<AnswerStatus, List<SheetData>> groupedCount = sheets.stream().filter(t -> !t.getGroup().equals("BLANK"))
                    .collect(Collectors.groupingBy(t -> t.getAnswerScores().get(iter - 1).getStatus()));

            groupedCount.forEach((k, v) -> environment.writeLn("\t" + k + ": " + v.size()));
            environment.writeLn("");
        }

        environment.writeLn("");

        // Ra�una prosje�ni broj bodova
        evaluateAverages(sheets, environment);

        return CommandStatus.CONTINUE;
    }

    /**
     * Ra�una prosjek
     *
     * @param sheets      Obrasci
     * @param environment Okru�enje za ras s ljuskom
     */
    private void evaluateAverages(List<SheetData> sheets, Environment environment) {
        double avg = sheets.stream().mapToDouble(sheet -> sheet.getTotalScore().getAsDouble()).average().getAsDouble();
        avg = Math.round(avg * 100);
        avg /= 100;

        environment.writeLn("Average score: " + avg);
        environment.writeLn("Average score by groups: ");

        Map<String, List<SheetData>> groupedSheets = sheets.stream().collect(Collectors.groupingBy(SheetData::getGroup));

        groupedSheets.forEach((group, data) -> {
            double avgGroup = data.stream().mapToDouble(t -> t.getTotalScore().getAsDouble()).average().getAsDouble();
            avgGroup = Math.round(avgGroup * 100);
            avgGroup /= 100;

            environment.writeLn("\tGroup " + group + ": " + avgGroup);
        });
    }
}
