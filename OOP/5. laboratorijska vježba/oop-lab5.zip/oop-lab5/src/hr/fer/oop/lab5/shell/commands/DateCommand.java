package hr.fer.oop.lab5.shell.commands;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
/**
 * Razred predstavlja komandu date za ljusku
 * @author Filip Kujundzic
 *
 */
public class DateCommand extends AbstractCommand {
	/**
	 * Konstruktor naredbe date; naslje�uje ime komande i njen opis
	 */
	public DateCommand() {
		super("date", "Displays the date.");
	}

	/**
	 * Naredba za izvr�avanje komande
	 * 
	 * @param executioner
	 *            okru�enje za rad s ljuskom
	 * @param message
	 *            argument koji predajemo naredbi
	 */
	@Override
	public CommandStatus execute(Environment executioner, String message) {
		DateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		System.out.println(dateformat.format(date));
		return CommandStatus.CONTINUE;
	}
}
