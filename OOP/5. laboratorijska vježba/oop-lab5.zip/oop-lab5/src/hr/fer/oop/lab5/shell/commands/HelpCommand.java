package hr.fer.oop.lab5.shell.commands;

import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;
import hr.fer.oop.lab5.shell.ShellCommand;
/**
 * Razred predstavlja naredbu type kojom ispisujemo podr�ane komande
 * u na�oj ljusci i kraj svake od njih odgovaraju�i opis.
 * @author Filip Kujundzic
 *
 */
public class HelpCommand extends AbstractCommand{
	
	/**
	 * Konstruktor naredbe help. Naslje�uje ime komande i njen opis.
	 */
	public HelpCommand() {
		super("help","Provides Help information for MyShell commands.");
	}

	/**
	 * Naredba kojom se izvr�ava komanda. Prima dva argumenta.
	 * 
	 * @param executioner
	 *            okru�enje kojim upravljamo ljuskom
	 * @param message
	 *           argumnet koji prima naredba (u ovom slu�aju null)
	 */
	@Override
	public CommandStatus execute(Environment executioner, String message) {
		for(ShellCommand command : executioner.commands()){
			executioner.writeLn(command.getCommandName() + ": " + command.getCommandDescription());
		}
		return CommandStatus.CONTINUE;
	}
	
	
}
