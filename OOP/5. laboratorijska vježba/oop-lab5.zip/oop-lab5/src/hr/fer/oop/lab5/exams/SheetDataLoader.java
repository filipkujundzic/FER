package hr.fer.oop.lab5.exams;

import hr.fer.oop.lab5.shell.Environment;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Razred u�itava podatke o obrascima i podatke o to�nim odgovorima te ih vra�a kao
 * listu, odnosno mapu
 *
 * @author Filip Kujundzic
 */
public class SheetDataLoader {
    /**
     * U�itavanje podataka o ispitu iz datoteke na zadanoj lokaciji
     *
     * @param location lokacija datoteke
     * @return lista sa spremljenim podatcima o ispitu
     */
    public static List<SheetData> loadSheets(Path location, Environment environment) {
        List<SheetData> sheets = new ArrayList<>();

        try {
            if (!Files.exists(location) || !Files.isReadable(location)) {
                environment.writeLn("File you requested does not exist.");
                return null;
            }
            
            Files.readAllLines(location).forEach(sheet -> {
                String[] splitData = sheet.split("\t");
                List<String> answers = new ArrayList<>();

                answers.addAll(Arrays.asList(splitData).subList(2, splitData.length));

                sheets.add(new SheetData(splitData[0], splitData[1], answers));
            });
        } catch (IOException e) {
            e.printStackTrace();
        }

        return sheets;
    }

    /**
     * U�itavanje to�nih odgovora iz datoteke na zadanoj lokaciji
     *
     * @param location lokacija datoteke
     * @return mapa sa spremljenim podatcima o to�nim odgovorima
     */
    public static Map<String, String[]> loadCorrectAnswers(Path location, Environment environment) {
        Map<String, String[]> correctAnswers = new HashMap<>();

        try {
            if (!Files.exists(location) || !Files.isReadable(location)) {
                environment.writeLn("File you requested does not exist.");
                return null;
            }

            Files.readAllLines(location).forEach(answerLine -> {
                String[] splitData = answerLine.split("\t", 2);
                correctAnswers.put(splitData[0], splitData[1].split("\t"));
            });
        } catch (IOException e) {
            e.printStackTrace();
        }

        return correctAnswers;
    }
}
