/**
 * 
 */
package hr.fer.oop.lab5.shell.commands;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import hr.fer.oop.lab5.shell.CommandStatus;
import hr.fer.oop.lab5.shell.Environment;

/**
 * Razred predstavlja komandu copy za ljusku
 * @author Filip Kujundzic
 *
 */
public class CopyCommand extends AbstractCommand {

	/**
	 * Konstruktr naredbe copy; naslje�uje ime komande i njen opis
	 */
	public CopyCommand() {
		super("copy", "Copies a file from source to destination");
	}

	@Override
	public CommandStatus execute(Environment environment, String argument) {
		String[] paths = argument.split(" ", 2);
		if (paths.length != 2) {
			environment.writeLn("Incorrectly set paths");
		} else {
			Path source = Paths.get(paths[0]).toAbsolutePath().normalize();
			Path destination = Paths.get(paths[1]).toAbsolutePath().normalize();

			if (!Files.isRegularFile(source)) {
				environment.writeLn("Source is a directory, which can't be copied using copy");
			} else {
				if (Files.isDirectory(destination)) {
					destination = destination.resolve(source.getFileName().toString());
				}
				try {
					BinaryStreamCopy.BinaryCopy(source.toString(), destination.toString());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return CommandStatus.CONTINUE;
	}

}


