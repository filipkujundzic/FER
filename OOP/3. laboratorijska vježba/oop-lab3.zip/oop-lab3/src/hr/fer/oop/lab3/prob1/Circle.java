package hr.fer.oop.lab3.prob1;

/**
 * Razred definira krug koji �e biti nacrtan.
 * @author Filip Kujundzic
 * @version 1.0
 */

public class Circle extends Shapes{
	
	private int cx;
	private int cy;
	private int r;
	
	/**
	 * Konstruktor koji stvara novi krug.
	 * @param cx Koordinata x sredi�ta kruga.
	 * @param cy Koordinata y sredi�ta kruga.
	 * @param r  Radijus kruga.
	 */
	public Circle(int cx, int cy, int r){
		this.cx = cx;
		this.cy = cy;
		this.r = r;
	}
	
	/**
	 * Konstruktor koji omogu�ava korisniku stvaranje kruga predavanjem reference na njega.
	 * @param original Referenca na krug.
	 */
	public Circle(Circle original){
		this.cx = original.cx;
		this.cy = original.cy;
		this.r = original.r;
	}
	
	/**
	 * Metoda ispituje da li pojedina to�ka pripada krugu.
	 * @param x Koordinata x to�ke za koju provjeravamo sadr�i li ju krug.
	 * @param y Koordinata y to�ke za koju provjeravamo sadr�i li ju krug.
	 * @return Metoda vra�a true ili false, ovisno o tome sadr�i li lik to�ku ili ne.
	 */
	public boolean containsPoint(int x, int y){
		int dx = x - cx;
		int dy = y - cy;
		return dx*dx + dy*dy <= r*r;
	}
}

