package hr.fer.oop.lab3.prob1;
/**
 * Razred definira jednakostrani�an trokut koji �e biti nacrtan.
 * @author Filip Kujundzic
 * @version 1.0
 */
public class Rectangle extends Shapes{

	private int x;
	private int y;
	private int width;
	private int height;
	
	/**
	 * Konstruktor koji stvara novi pravokutnik.
	 * @param x Koordinata x donjeg lijevog vrha pravokutnika.
	 * @param y Koordinata y donjeg lijevog vrha pravokutnika.
	 * @param width �irina pravokutnika.
	 * @param height Duljina stranice pravokutnika.
	 */
	public Rectangle(int x, int y, int width, int height){
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	/**
	 * Konstruktor koji omogu�ava korisniku stvaranje pravokutnika predavanjem reference na njega.
	 * @param original Referenca na jednakostrani�ni trokut.
	 */
	public Rectangle(Rectangle original){
		this.x = original.x;
		this.y = original.y;
		this.width = original.width;
		this.height = original.height;
	}
	/**
	 * Metoda ispituje da li pojedina to�ka pripada pravokutniku.
	 * @param x Koordinata x to�ke za koju provjeravamo sadr�i li ju pravokutnik.
	 * @param y Koordinata y to�ke za koju provjeravamo sadr�i li ju pravokutnik.
	 * @return Metoda vra�a true ili false, ovisno o tome sadr�i li lik to�ku ili ne.
	 */
	public boolean containsPoint(int tx, int ty) {
		if(tx < x) return false;
		if(ty < y) return false;
		if(tx >= x + width) return false;
		if(ty >= y + height) return false;
		return true;
	}	
}

