package hr.fer.oop.lab3.prob2_1;
import java.util.Iterator;

/**
 * Razred SimpleHashtable<K, V> predstavlja tablicu raspr�enog adresiranja
 * koja omogu�uje pohranu ure�enih parova (klju�, vrijednost).
 * @author Filip Kujund�i�
 *
 * @param <K> predstavlja tip klju�a
 * @param <V> predstavlja tip vrijednosti
 */

public class SimpleHashtable<K,V> implements Iterable<SimpleHashtable.TableEntry<K,V>> {
	
	private int size;
	private TableEntry<K, V>[] table;
	
	/**
	 * Default konstruktor koji stvara tablicu veli�ine 16 slotova.
	 */
	public SimpleHashtable() {
		this(16);
	}
	
	/**
	 * Konstruktor koji prima jedan argument i stvara hash tablicu veli�ine 
	 * koja je potencija broja 2 koja je prva ve�a ili jednaka predanom broju 
	 * (npr. ako se zada 14, bira se 16).
	 * @param capacity �eljeni po�etni kapacitet tablice
	 */
	@SuppressWarnings("unchecked")
	public SimpleHashtable(int capacity) {
		
		int newcapacity = 1;
		
		while(newcapacity < capacity) {
			newcapacity*=2;
		}
		
		table = new TableEntry[newcapacity];
		
	}
	
	/**
	 * Metoda koja sprema element u povezanu listu �iji je po�etak pretinac tablice.
	 * Vrijednost pretinca odre�uje se metodom hashCode() nad parametrom key, nakon �ega
	 * se nad dobivenim rezultatom obavlja operacija modulo sa veli�inom tablice.
	 * Ako ve� postoji element s istim klju�em, postoje�em elementu se samo a�urira vrijednost, 
	 * a ne stvara se novi.
	 * @param key klju� elementa (ne smije biti null)
	 * @param value vrijednost elementa
	 */
	public void put(K key, V value) {
		
		int slot = Math.abs(key.hashCode()) % table.length;
		
		if(table[slot]==null) {
			table[slot] = new TableEntry(key, value, null);
			size++;
		}
		else {
			TableEntry<K, V> temp = table[slot];
			
			if(table[slot].key==key)
				table[slot].setValue(value);
			else{
				while (temp.next!= null) {
					if(temp.next.key.equals(key)) {
						temp.next.setValue(value);
						break;
					}
					else{
						temp = temp.next;
					}
				}
				temp.next = new TableEntry(key, value, null);
				size++;
			}
		}
	}	
	
	/**
	 * Ova metoda pomo�u klju�a tra�i vrijednost u hash tablici.
	 * @param key klju� elementa liste
	 * @return vrijednost elementa liste �iji je klju� parametar
	 */
	public V get(K key) {
		
		int slot = Math.abs(key.hashCode()) % table.length;
		
		TableEntry<K, V> temp = table[slot];
		
		while(temp!=null) {
			if(temp.key.equals(key)) {
				return temp.getValue();
			}
			else
				temp = temp.next;
		}
		return null;
	}
	
	/**
	 * Metoda koja vra�a broj elemenata sadr�an u hash tablici.
	 * @return broj elemenata u hash tablici
	 */
	public int size() {
		return size;
	}
	
	/**
	 * Metoda ispituje sadr�i li hash tablica element sa zadanim klju�em.
	 * @param key klju� elementa
	 * @return true ako sadr�i element sa zadanim klju�em, ina�e false
	 */
	public boolean containsKey(K key) {
		
		int slot = Math.abs(key.hashCode()) % table.length;
		
		TableEntry<K, V> temp = table[slot];
		
		while(temp!=null) {
			if(temp.key.equals(key)) {
				return true;
			}
			else
				temp = temp.next;
		}
		return false;
	}
	
	/**
	 * Metoda ispituje sadr�i li hash tablica element sa zadanom vrijedno��u.
	 * @param value vrijednost tra�enog elementa
	 * @return true ako postoji element sa zadanom vrijedno��u, ina�e false
	 */
	public boolean containsValue(V value) {
		
		for(int i=0, n=table.length; i<n; i++){
			
			TableEntry<K, V> temp = table[i];
			
			while(temp!=null) {
				if(temp.value.equals(value)) {
					return true;
				}
				else
					temp = temp.next;
			}	
		}
		return false;	
	}
	
	/**
	 * Metoda koja iz hash tablice bri�e element sa zadanim klju�em.
	 * @param key klju� elementa za brisanje
	 */
	public void remove(K key) {
		
		int slot = Math.abs(key.hashCode()) % table.length;
		
		if(table[slot].key == key) {
            table[slot] = table[slot].next;
            size--;
            return;
	    }
	   
	    TableEntry<K, V> preTemp = table[slot];
	    TableEntry<K, V> postTemp = table[slot].next;
	   
	    while(postTemp != null) {
	            if(postTemp.key == key) {
	                    preTemp.next = postTemp.next;
	                    size--;
	                    return;
	            }
	            preTemp = postTemp;
	            postTemp = postTemp.next;
	    }
	}
	
	/**
	 * Metoda vra�a true ako je hash tablica prazna.
	 * @return true ako je hash tablica prazna, ina�e false
	 */
	public boolean isEmpty() {
		return size==0;
	}
	
	/**
     * Modificirani ispis hash tablice.
     */
    @Override
    public String toString() {
            StringBuilder s = new StringBuilder("{ ");
           
            for(int i=0, n=table.length; i<n; i++){
    			
    			TableEntry<K, V> temp = table[i];
    			
    			while(temp!=null) {
    					s.append(temp + " ");
    					temp = temp.next;
    			}	
    		}
    		return s.append(" }").toString();
            
    }
	
	/**
	 * Tvornica iteratora za ovaj razred.
	 */
	public Iterator<TableEntry<K,V>> iterator() {
		return new SimpleHashtableIterator();
	}
	
	/**
	 * Razred Iterator za razred SimpleHashtable.
	 * @author Antonio
	 *
	 * @param <K> tip klju�a
	 * @param <V> tip vrijednosti
	 */
	private class SimpleHashtableIterator<K,V> implements Iterator<SimpleHashtable.TableEntry<K,V>> {
		
		private int currentSlot;
		private int currentNode;
		
		/**
		 * Konstruktor koji stvara Iterator za razred SimpleHashtable.
		 */
		public SimpleHashtableIterator(){
			this.currentSlot = 0;
			this.currentNode = 0;
		}
		
		/**
		 * Ova metoda vra�a true ako postoji sljede�i element u hash tablici, ina�e vra�a false.
		 */
		@SuppressWarnings("unchecked")
		@Override
		public boolean hasNext() {
			if(this.currentSlot >= SimpleHashtable.this.table.length )
				return false;
			
			TableEntry<K,V> temp = (TableEntry<K,V>) SimpleHashtable.this.table[currentSlot];
			int index = 0;
			
			while(index<this.currentNode){
				temp = temp.next;
				index++;
			}
			
			if(temp!=null)
				return true;
			
			if(this.currentSlot+1 < SimpleHashtable.this.table.length)
				if(SimpleHashtable.this.table[currentSlot+1]!=null)
					return true;
			
			return false;
		}
		
		/**
		 * Metoda vra�a sljede�i �lan iteracije.
		 */
		@SuppressWarnings("unchecked")
        @Override
		public SimpleHashtable.TableEntry<K,V> next() {
			TableEntry<K,V> temp = (TableEntry<K,V>) SimpleHashtable.this.table[currentSlot];
			int index = 0;
			
			while(index != this.currentNode) {
                 temp = temp.next;
                 index++;
	        }
	        
	        if(temp.next != null) {
	                 this.currentNode++;
	                 return temp;
	        }
	        
	        this.currentSlot++;
	        this.currentNode = 0;
	        return temp;
		}
	}
	
	static class TableEntry<K, V> {
		
		private K key;
		private V value;
		private TableEntry<K, V> next;
		
		/**
		 * Konstruktor za razred TableEntry, stvara novi element
		 * i incijalizira mu vrijednosti.
		 * @param key klju� elementa
		 * @param value vrijednost elementa
		 * @param table referenca na sljede�i element u listi
		 */
		public TableEntry(K key, V value, TableEntry<K, V> table) {
			this.key = key;
			this.value = value;
			this.next = table;
		}
		
		/**
		 * Vra�a klju� elementa.
		 * @return klju� elementa.
		 */
		public K getKey(){
			return key;
		}
		
		/**
		 * Vra�a vrijednost elementa.
		 * @return vrijednost elementa
		 */
		public V getValue(){
			return value;
		}
		
		/**
		 * Postavlja vrijednost elementa.
		 * @param value vrijednost elementa
		 */
		public void setValue(V value){
			this.value = value;
		}
		
		/**
		 * Modificirani ispis elementa.
		 */
		@Override
		public String toString() {
             return "[ " + this.key + " : "+ this.value + " ]";
		}

	}
	
}

