package hr.fer.oop.lab3.prob1;
import java.lang.Math;
/**
 * Razred definira jednakostrani�an trokut koji �e biti nacrtan.
 * @author Filip Kujundzic
 * @version 1.0
 */
public class EquilateralTriangle extends Shapes{
	
	int ax;
	int ay;
	int length;
	
	/**
	 * Konstruktor koji stvara novi jednakostrani�ni trokut.
	 * @param ax Koordinata x vrha A (donjeg lijevog) jednakostrani�nog trokuta.
	 * @param ay Koordinata y vrha A (donjeg lijevog) jednakostrani�nog trokuta.
	 * @param length Duljina stranice jednakostrani�nog trokuta.
	 */
	public EquilateralTriangle(int ax, int ay, int length){
		this.ax = ax; 
		this.ay = ay;
		this.length = length;
	}
	/**
	 * Konstruktor koji omogu�ava korisniku stvaranje jednakostrani�nog trokuta predavanjem reference na njega.
	 * @param oringinal Referenca na jednakostrani�ni trokut.
	 */
	public EquilateralTriangle(EquilateralTriangle oringinal){
		this.ax = oringinal.ax;
		this.ay = oringinal.ay;
		this.length = oringinal.length;
	}
	
	/**
	 * 
	 * @param x1 Koordinata x prve to�ke kroz koju �elimo povu�i pravac
	 * @param y1 Koordinata y druge to�ke kroz koju �elimo povu�i pravac
	 * @param x2 Koordinata x druge to�ke kroz koju �elimo povu�i pravac
	 * @param y2 Koordinata y druge to�ke kroz koju �elimo povu�i pravac
	 * @param x  Koordinata x to�ke za koju se pitamo da li je u trokutu.
	 * @return Y vrijednost pravca kroz dvije to�ke
	 */
	private int calculateLine (int x1, int y1, int x2, int y2, int x) { 
		return (int)((x - x1)*(y2-y1)/(x2 - x1) + y1); 
	}
	
	/**
	 * Metoda ispituje da li pojedina to�ka pripada jednakostrani�nom trokutu.
	 * @param x Koordinata x to�ke za koju provjeravamo sadr�i li ju jednakostrani�ni trokut.
	 * @param y Koordinata y to�ke za koju provjeravamo sadr�i li ju jednakostrani�ni trokut.
	 * @return Metoda vra�a true ili false, ovisno o tome sadr�i li lik to�ku ili ne.
	 */
	public boolean containsPoint(int x,int y){
		int bx = ax + length;
		int by = ay;
		int cx = ax + (int)(length/2);
		int cy = ay - (int)(length*Math.sqrt(3)/2);
		if( y <= calculateLine(ax, ay, bx, by, x) && y >= (calculateLine(ax,ay,cx,cy,x)) &&
				y >= calculateLine(bx, by, cx, cy, x)) return true;
		return false;
	}
}

