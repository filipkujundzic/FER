package hr.fer.oop.lab3.prob2;

/**
 * Tablica raspr�enog adresiranja zasnovna na jednostruko povezanoj listi.
 * 
 * @author Filip Kujundzic
 * @version 1.0
 */
public class SimpleHashtable<K, V> {

	/**
	 * TableEntry je jedan �vor listi.
	 * 
	 * @param <K>
	 *            Predstavlja tip klju�a.
	 * @param <V>
	 *            Predstavlja tip vrijednosti.
	 * @param next
	 *            Slijede�i �vor u listi.
	 */
	private class TableEntry<K, V> {
		private final K key;
		private V value;
		private TableEntry<K, V> next;

		/**
		 * Konstruktor koji stvara TableEntry.
		 * 
		 * @param key
		 *            Predstavlja tip klju�a.
		 * @param value
		 *            Predstavlja tip vrijednosti.
		 * @param entry
		 *            Idu�i objekt s kojim je TableEntry povezan.
		 */
		public TableEntry(K key, V value, TableEntry<K, V> entry) {
			this.key = key;
			this.value = value;
			this.next = entry;
		}

		/**
		 * Metoda vra�a klju�.
		 * 
		 * @return Klju�.
		 */
		public K getKey() {
			return key;
		}

		/**
		 * Metoda vra�a vrijednost.
		 * 
		 * @return Vrijednost.
		 */
		public V getValue() {
			return value;
		}

		/**
		 * Metoda za postavljanje vrijednosi.
		 * 
		 * @param setter
		 *            Postavljena vrijednost.
		 */
		public void setValue(V setter) {
			value = setter;
		}

		/**
		 * Metoda toString
		 * 
		 * @return Prikaz TableEntry-ja u obliku stringa.
		 */
		@Override
		public String toString() {
			return "Key : " + key + ", value :" + value;
		}
	}

	/**
	 * table je tablica TableEntry-ja koja predstavlja hash tablicu size je
	 * integer koji predstavlja broj elemenata u tablici
	 */
	private TableEntry<K, V>[] table = null;
	private int size;

	/**
	 * Konstruktor SimpleHashTable stvara tablicu kapaciteta vrijednosti
	 * varijable capacity.
	 * 
	 * @param capacity
	 *            Parametar koji odre�uje veli�inu hash tablice.
	 * @exception Iznimka
	 *                koja se doga�a kada je kapacitet manji ili jednak nuli
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	public SimpleHashtable(int capacity) {
		if (capacity <= 0)
			throw new IllegalArgumentException("Capacity of a table must be a positive number greater than zero!");
		for (int i = 0; i < capacity; i++) {
			if ((int) Math.pow(2, i) >= capacity) {
				table = new TableEntry[(int) (Math.pow(2, i))];
				for (int j = 0; j < (int) Math.pow(2, j); j++){
					table[j] = null;
					break;
				}
			}
		}
	}

	/**
	 * Konstruktor stvara hash tablicu defaultne veli�ine 16
	 */
	@SuppressWarnings("unchecked")
	public SimpleHashtable() {
		table = new TableEntry[16];
	}

	/**
	 * Metoda put stvara novi �vor u listi ili a�urira postoje�i s istim klju�em
	 * 
	 * @param key
	 *            Klju� �vora.
	 * @param value
	 *            Vrijednost �vora.
	 * @exception Ako
	 *                je klju� null.
	 */
	public void put(K key, V value) {
		if (key == null)
			throw new NullPointerException("Key can't be null!");
		int position = (int) Math.abs(key.hashCode() % table.length);
		TableEntry<K, V> last = table[position];
		if (table[position] == null) {
			table[position] = new TableEntry<K, V>(key, value, null);
			size++;
			return;
		}
		while (last.next != null) {
			if (last.key == key) {
				last.setValue(value);
				return;
			}
			last = last.next;
		}
		last.next = new TableEntry<K, V>(key, value, null);
		size++;
	}

	/**
	 * Metoda vra�a vrijednost koji ima odgovaraju�i klju�.
	 * 
	 * @param key
	 *            String koji �e se tra�iti u hash tablici.
	 * @return Metoda vra�a vrijednost koju ima zadani klju� ili null ako klju�
	 *         ne postoji.
	 */
	public V get(K key) {
		TableEntry<K, V> wanted = table[Math.abs(key.hashCode() % table.length)];
		while (wanted.getKey() != key && wanted != null)
			wanted = wanted.next;
		if (wanted.getKey() == key)
			return wanted.getValue();
		return null;
	}

	/**
	 * Metoda vra�a broj odrednica u tablici.
	 * 
	 * @return Broj odrednica.
	 */
	public int size() {
		return size;
	}

	/**
	 * Metoda koja daje odgovor na pitanje postoji li ili ne postoji odre�eni
	 * klju� u tablici.
	 * 
	 * @param key
	 *            Parametar koji se tra�i
	 * @return True ako je prona�en ina�e false
	 */
	public boolean containsKey(K key) {
		TableEntry<K, V> wanted = table[Math.abs(key.hashCode()) % table.length];
		while (wanted != null && wanted.getKey() != key)
			wanted = wanted.next;
		if (wanted == null)
			return false;
		else
			return true;
	}

	/**
	 * Metoda koja daje odgovor da li je vrijednost u tablci ili nije
	 * 
	 * @param value
	 *            Parametar koji se tra�i u tablci
	 * @return True ako je parametar prona�en, ina�e false
	 */
	public boolean containsValue(V value) {
		for (int i = 0; i < table.length; i++) {
			TableEntry<K, V> wanted = table[i];
			while (wanted != null && wanted.getValue() != value)
				wanted = wanted.next;
			if (wanted != null)
				return true;
		}
		return false;
	}

	/**
	 * Metoda uklanja odrednicu iz tablice.
	 * 
	 * @param key
	 *            Klju� koji treba biti uklonjen.
	 */
	public void remove(K key) {
		TableEntry<K, V> wanted = table[Math.abs(key.hashCode() % table.length)];
		while (wanted != null && wanted.next.getKey() != key)
			wanted = wanted.next;
		if (!(wanted == null)) {
			wanted.next = wanted.next.next;
			size--;
		}
	}

	/**
	 * Metoda daje informaciju da li je tablica prazna ili nije
	 * 
	 * @return True ako je prazna ina�e false
	 */
	public boolean isEmpty() {
		if (size == 0)
			return true;
		else
			return false;
	}

	/**
	 * Metoda daje predstavnika tablice u string obliku
	 * 
	 * @return String vrijednost tablice
	 */
	@Override
	public String toString() {
		String output = null;
		for (int i = 0; i < table.length; i++) {
			TableEntry<K, V> current = table[i];
			while (current != null) {
				if (output == null)
					output = current.toString();
				else
					output += current.toString();
				output += "\n";
				current = current.next;
			}
		}
		return output;
	}
}
