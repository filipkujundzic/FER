package hr.fer.oop.lab3.prob1;
import hr.fer.oop.lab3.pic.Picture;
/**
 * Apstraktni razred kojeg naslje�uju svi likovi koji �e se crtati.
 * @author Filip Kujundzic
 * @version 1.0
 */
public abstract class Shapes {
	/**
	 * Metoda koja crta likove na slici.
	 * @param p Referenca na crno - bijelu sliku.
	 */
	public void drawOnPicture(Picture p) {
		int w = p.getWidth();
		int h = p.getHeight();
		for(int y = 0; y < h; y++) {
			for(int x = 0; x < w; x++) {
				if(this.containsPoint(x, y)) {
					p.turnPixelOn(x, y);
				}
			}
		}
	}
	
	/**
	 * Apstraktna metoda koja provjerava sadr�i li lik odre�enu to�ku.
	 * @param x Koordinata x za koju se provjerava sadr�i li ju lik.
	 * @param y Koordinata y za koju se provjerava sadr�i li ju lik.
	 * @return Metoda vra�a true ili false, ovisno o tome sadr�i li lik to�ku ili ne.
	 */
	public abstract boolean containsPoint(int x, int y);
}
