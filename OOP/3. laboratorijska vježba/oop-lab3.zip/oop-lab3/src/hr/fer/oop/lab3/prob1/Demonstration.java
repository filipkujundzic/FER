package hr.fer.oop.lab3.prob1;
import hr.fer.oop.lab3.pic.Picture;
import hr.fer.oop.lab3.pic.PictureDisplay;
/**
 * Razred demonstrira crtanje likova na crno - bijeloj slici. 
 * To�ka koju lik sadr�i ozna�ena je s "*" a ako ne sadr�i s "."
 * U demonstraciji se crtaju dva pravokutnika, dva kruga te dva jednakostrani�na trokuta.
 * @author Filip Kujundzic
 * @version 1.0
 */
public class Demonstration {

	public static void main(String[] args) {
		Picture pic = new Picture(100, 50);
//		Picture pic = new Picture(1000,5000);
		
		Rectangle r1 = new Rectangle(1,1, 25, 5);
		Rectangle r2 = new Rectangle(30,25,10,4);
		r1.drawOnPicture(pic);
		r2.drawOnPicture(pic);
		
		Circle c1 = new Circle(40,35,4);
		Circle c2 = new Circle(80,20,5);
		c1.drawOnPicture(pic);
		c2.drawOnPicture(pic);
		
		EquilateralTriangle t1 = new EquilateralTriangle(20,50,5);
		EquilateralTriangle t2 = new EquilateralTriangle(50,25,9);
		t1.drawOnPicture(pic);
		t2.drawOnPicture(pic);
		pic.renderImageToStream(System.out);
		
//		PictureDisplay.showPicture(pic);
	}	
}
