package hr.fer.oop.lab2.prob1;
import java.util.Scanner;

public class Rectangle {

	public static void main(String[] args) {
		
		double a;
		double b;
		
		// dobivanje podataka sa standardnog ulaza ako nema argumenata
			if(args.length == 0){
				Scanner sc = new Scanner(System.in);
				a = scanner ("width",sc);
				b = scanner ("height",sc);
				sc.close();
			}	
				
		// izlaz iz programa ako je unesen krivi broj argumenata
			else if(args.length != 2){
			System.err.println("Invalid number of arguments was provided.");
			return;
			}
		
			// pretvorba stringa unesenog preko naredbenog retka u double
			else{
				a = Double.parseDouble(args[0]);
				b = Double.parseDouble(args[1]);
			}		
						
		double area = area(a,b);
		double perimeter = perimeter(a,b);
		
				System.out.println("You have specified a rectangle of width " + a + " and height "
				+ b + ". Its area is " + area + " and its perimeter is " + perimeter);
	}
	
		//opseg
		private static double area(double x, double y){
			return x*y;
		}
		
		//povrsina
	private static double perimeter(double x, double y){
			return 2*(x+y);
	}
	
		//citanje podatka sa standardnog ulaza
	public static double scanner(String word, Scanner scan) {
		while(true) {
			System.out.print("Please provide " + word + ": ");
			String string = scan.nextLine();
			string = string.trim();
			
			if (string.isEmpty()) {
				System.out.println("The input must not be blank.");
			}
			
			else {
				double number = Double.parseDouble(string);
				if(number < 0) {
					System.out.println("The " + word + " must not be negative.");
				}
				else {
					return number;
				}
			}
		}
	}
		
}

