package hr.fer.oop.lab2.prob2;

class TreeNode {
	TreeNode left;
	TreeNode right;
	String data;
}

class TreeProgram {
	public static void main(String[] args) {
		TreeNode node = null;
		node = insert(node, "Jasna");
		node = insert(node, "Ana");
		node = insert(node, "Ivana");
		node = insert(node, "Anamarija");
		node = insert(node, "Vesna");
		node = insert(node, "Kristina");
		
		System.out.println("Writing tree inorder:");
		writeTree(node);
		
		node = reverseTreeOrder(node);
		System.out.println("Writing reversed tree inorder:");
		
		writeTree(node);
		int size = sizeOfTree(node);
		System.out.println("Number of nodes in tree is "+size+".");
		
		boolean found = containsData(node, "Ivana");
		System.out.println("Searched element is found: "+found);
		
		boolean found1 = containsData2(node, "Kristina");
		System.out.println("Searched element is found: "+found1);
	}
	
	static boolean containsData(TreeNode treeRoot, String data) {
		if(treeRoot == null)
			return false;
		else if(data.compareTo(treeRoot.data) == 0)
			return true;
		else if(data.compareTo(treeRoot.data) < 1)
			return containsData(treeRoot.left,data);
		else 
			return containsData(treeRoot.right,data);
	}
	
	static int sizeOfTree(TreeNode treeRoot) {
		if(treeRoot == null)
			return 0;
		else 
			return 1 + sizeOfTree(treeRoot.right) + sizeOfTree(treeRoot.left);
	}
	
	static TreeNode insert(TreeNode treeRoot, String data) {
		if(treeRoot == null){
			TreeNode newnode = new TreeNode();
			newnode.data = data;
			newnode.left = null;
			newnode.right = null;
			return newnode;
		}
		else if (data.compareTo(treeRoot.data) < 1)
			treeRoot.left = insert(treeRoot.left,data);
		else 
			treeRoot.right = insert(treeRoot.right,data);
		return treeRoot;
	}
	
	static void writeTree(TreeNode treeRoot) {
		if(treeRoot != null){
			writeTree(treeRoot.left);
			System.out.println(treeRoot.data);
			writeTree(treeRoot.right);
		}
	}
	
	static TreeNode reverseTreeOrder(TreeNode treeRoot) {
		if(treeRoot == null)
			return null;
		
		TreeNode node = new TreeNode();
		node = treeRoot.left;
		treeRoot.left = treeRoot.right;
		treeRoot.right = node;
		
		reverseTreeOrder(treeRoot.left);
		reverseTreeOrder(treeRoot.right);
		return treeRoot;
	}
	
	static boolean containsData2(TreeNode treeRoot,String data){
		if (treeRoot == null) {
		    return false;
		}

		if (treeRoot.data == data){
		    return true;
		} 
		else {
		    return containsData2(treeRoot.left,data) || containsData2(treeRoot.right,data);
		}
	}
}