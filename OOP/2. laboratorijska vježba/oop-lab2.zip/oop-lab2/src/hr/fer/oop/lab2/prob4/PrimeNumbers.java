package hr.fer.oop.lab2.prob4;

public class PrimeNumbers {
	
	public static void main(String[] args){
		if(args.length == 0){
			System.out.println("Invalid number of arguments. Program expects 1 argument.");
			System.exit(1);
		}
		firstPrimeNumbers(Integer.parseInt(args[0]));
	}
	
	static void firstPrimeNumbers(int numberOfPrimes){
		
		System.out.println("You requested calculation of first " + numberOfPrimes + " prime numbers. Here they are:");
		for(int i = 2,count = 1; count <= numberOfPrimes; i++) {
			boolean isPrime = true;
			for(int j = 2; isPrime == true && j < i; j++)
				if(i % j == 0)
					isPrime = false;
			if(isPrime == true) {
				System.out.println(count + ". " + i);
				count++;
			}
		}
	}
}
			