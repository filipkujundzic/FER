package hr.fer.oop.lab2.prob6;

public class Shapes {

	public static void main(String[] args) {
		methodA();
		methodB();
		System.out.println();
		methodC();
		methodD();
	}
	
	private static void method1(){
		
		System.out.format("\\        /\n");
		System.out.format(" \\______/\n");
	}
	
	public static void method2(){
		System.out.format("  ______  \n");
		System.out.format(" /      \\\n");	
		System.out.format("/        \\\n");
	}
	
	private static void method3(){
		System.out.format("+--------+\n");
	}
	
	private static void methodA(){
		method3();
		method1();
		method2();
		method3();
	}
	
	public static void methodB(){
		method2();
		method1();
	}
	
	public static void methodC(){
		method1();
		method3();
	}
	
	public static void methodD(){
		method2();
		method3();
	}
}

