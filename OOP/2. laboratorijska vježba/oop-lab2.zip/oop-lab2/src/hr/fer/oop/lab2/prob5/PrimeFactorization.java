package hr.fer.oop.lab2.prob5;

public class PrimeFactorization {

	public static void main(String[] args) {
		
		if(args.length == 0){
			System.out.println("Invalid number of arguments. Program expects 1 argument.");
			System.exit(1);
		}
		factorize(Integer.parseInt(args[0]));
	}

	
	static void factorize(int number){
		int div = 2;
		
		System.out.println("You requested decomposition of number " + number + " into prime factors. Here they are:");
			while(number != 0){
				if(number % div != 0)
					div++;
				else{
					number /= div;
					System.out.println(div);
					if(number == 1) break;
				}
			}
	}

}
