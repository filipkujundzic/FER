package hr.fer.oop.lab2.prob3;
import java.lang.Math;


public class Roots {

	public static void main(String[] args) {
		if(args.length != 3){
			System.out.println("Invalid number of arguments. Program expects 3 arguments.");
			System.exit(1);
		}
		else if(Float.parseFloat(args[2]) <= 1){
			System.out.println("Invalid root argument. Must be greater than 1");
			System.exit(1);
		}
        complexRoots(Float.parseFloat(args[0]),Float.parseFloat(args[1]),Integer.parseInt(args[2]));
		
	}
	
	static void complexRoots(float re,float im,int n){
		double modul = Math.sqrt(re * re + im * im);
		double sqrtModul = Math.pow(modul,1/(double)n);
		double argument = Math.atan(im / re);
		
		System.out.println("You requested calculation of " + n+ ".roots. Solutions are:");
		for(int k=0; k<n; k++){
			re = (float) (sqrtModul * Math.cos((argument + 2 * k * Math.PI)/ (double)n));
			im = (float) (sqrtModul * Math.sin((argument + 2 * k * Math.PI)/ (double)n));
			System.out.println(k+1+") " + (int) re + (im < 0 ? " - " : " + ") + (int)Math.abs(im)+"i");
		}
	}

}
