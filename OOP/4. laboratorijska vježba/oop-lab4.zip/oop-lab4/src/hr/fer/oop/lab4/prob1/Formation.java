package hr.fer.oop.lab4.prob1;

/**
 * Enumeracija definira mogu�e formacije.
 * 
 * @author Filip Kujundzic
 * @version 1.0
 */
public enum Formation {
	F442, F352, F541
}
