package hr.fer.oop.lab4.prob1;

/**
 * Enumeracija definira pozicije na kojima nogometa�i mogu igrati.
 * 
 * @author Filip Kujundzic
 * @version 1.0
 */
public enum PlayingPosition {
	FW, MF, DF, GK
}
