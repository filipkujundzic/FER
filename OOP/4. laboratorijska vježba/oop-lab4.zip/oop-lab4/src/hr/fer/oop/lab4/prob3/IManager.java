package hr.fer.oop.lab4.prob3;

import java.util.function.Predicate;

import hr.fer.oop.lab4.prob1.FootballPlayer;
import hr.fer.oop.lab4.prob2.IManageableTeam;
import hr.fer.oop.lab4.prob2.NotEligiblePlayerException;

/**
 * Su�elje s metodama za upravljanje timom
 * 
 * @author Filip Kujundzic
 *
 */
public interface IManager {
	/**
	 * Metoda za registraciju igra�a
	 * 
	 * @param offeredPlayers
	 *            Igra�i koji su na raspolaganju za registraciju
	 * @param criteria
	 *            Kriterij prema kojem se odre�uje koji �e se igra�i
	 *            registrirati
	 * @throws UnemployedCoachException
	 *             Iznimka u slu�aju da trener nema tim
	 * @throws NotEligiblePlayerException
	 *             Iznimka u slu�aju da igra� nije kvalificiran
	 */
	public void registerPlayers(Iterable<FootballPlayer> offeredPlayers, Predicate<FootballPlayer> criteria)
			throws UnemployedCoachException, NotEligiblePlayerException;

	/**
	 * Metoda za odabir po�etnih 11
	 * 
	 * @param criteria
	 *            Kriterij prema kojem se odabire po�etnih 11
	 * @throws UnemployedCoachException
	 *             iznimka u slu�aju da trener nema tim
	 */
	public void pickStartingEleven(Predicate<FootballPlayer> criteria) throws UnemployedCoachException;

	/**
	 * Metoda kojom trener forsira svoju omiljenu formaciju
	 * 
	 * @throws UnemployedCoachException
	 *             slu�aju da je trener nezaposlen
	 */
	public void forceMyFormation() throws UnemployedCoachException;

	/**
	 * Metoda za postavljanje tima kojim �e trener upravljati
	 * 
	 * @param team
	 *            tim kojim �e trener upravljati
	 */
	public void setManagingTeam(IManageableTeam team);

}
