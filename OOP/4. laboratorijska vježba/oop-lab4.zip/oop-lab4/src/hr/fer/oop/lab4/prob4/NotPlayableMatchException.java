package hr.fer.oop.lab4.prob4;

/**
 * Klasa implementira iznimku u slu�aju neigrive utakmice
 * 
 * @author Filip Kujundzic
 * @version 1.0
 */
public class NotPlayableMatchException extends Exception {
	/**
	 * Konstruktor koji omogu�uje stvaranje nove iznimke
	 * 
	 * @param message
	 *            poruka koju �elimo ispisati prilikom nastajanja iznimke
	 */
	public NotPlayableMatchException(String message) {
		super(message);
	}
}
