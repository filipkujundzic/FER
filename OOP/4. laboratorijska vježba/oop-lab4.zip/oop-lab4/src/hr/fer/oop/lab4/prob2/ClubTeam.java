package hr.fer.oop.lab4.prob2;

import java.util.LinkedHashSet;

import hr.fer.oop.lab4.prob1.FootballPlayer;
import hr.fer.oop.lab4.prob1.Formation;

/**
 * Klasa modelira klupski nogometni tim koji naslje�uje klasu Tim.
 * 
 * @author Filip Kujundzic
 * @version 1.0
 *
 */
public class ClubTeam extends Team {
	/**
	 * {@value #reputation} Reputacija nogometnog tima (cijeli broj u rasponu
	 * [0,100])
	 */
	private int reputation;
	/**
	 * {@value #MAX_STARTING_PLAYERS} Maximalni broj igra�a.
	 */
	private static final int MAX_STARTING_PLAYERS = 25;
	/**
	 * {@value #MAX_REP} maksimalna reputacija kluba
	 */
	private static final int MAX_REP = 100;
	/**
	 * {@value #MIN_REP} minimalna reputacija kluba
	 */
	private static final int MIN_REP = 0;

	/**
	 * Konstruktor koji omogu�uje stvaranje novog klupskog tima
	 * 
	 * @param name
	 *            Ime kluba
	 * @param formation
	 *            Formacija kluba
	 * @param reputation
	 *            Reputacija kluba
	 */
	public ClubTeam(String name, Formation formation, int reputation) {
		super(name, formation);
		if (MIN_REP < 0 || reputation > MAX_REP)
			throw new IllegalArgumentException("Reputacija mora biti u rasponu [0,100] a ne: " + reputation);
		this.reputation = reputation;

		registeredPlayers = new LinkedHashSet<FootballPlayer>(MAX_STARTING_PLAYERS);

	}

	/**
	 * Metoda za dohva�anje reputacije kluba
	 * 
	 * @return reputacija kluba
	 */
	public int getReputation() {
		return reputation;
	}

	/**
	 * Metoda za postavljanje reputacije kluba
	 * 
	 * @param reputatiton
	 *            reputacija koja se �eli postaviti klubu
	 */
	public void setReputation(int reputatiton) {
		this.reputation = reputatiton;
	}

	/**
	 * Metoda za ra�unanje ratinga tima po formuli 0.7*mom�adski duh +
	 * 0.3*vje�tina tima
	 * 
	 * @return izra�unati rating tima
	 */
	@Override
	public double calculateRating() {
		return 0.7 * this.calculateTeamSpirit() + 0.3 * calculateTeamSkill();
	}

	/**
	 * Metoda za registracju igra�a
	 * 
	 * @param player
	 *            igra� koji se �eli registrirati
	 */
	@Override
	public void registerPlayer(FootballPlayer player) throws NotEligiblePlayerException {
		if (registeredPlayers.contains(player))
			throw new NotEligiblePlayerException(
					"Igra� " + player.getName() + " se ve� nalazi u kolekciji registriranih igra�a.");
		if (registeredPlayers.size() > MAX_STARTING_PLAYERS)
			throw new NotEligiblePlayerException(
					"Igra� " + player.getName() + " se ne mo�e registrirati jer nema mjesta u timu.");
		if (player.getPlayingSkill() < reputation)
			throw new NotEligiblePlayerException(
					"Igra� " + player.getName() + "se ne mo�e registrirati jer nije dovoljno vje�t.");
		registeredPlayers.add(player);
	}

	/**
	 * Metoda koja ispituje da li mogu�e registrirati igra�a
	 * 
	 * @param player
	 *            igra� za kojeg se �eli provjeriti da li ga je mogu�e
	 *            registrirati
	 */
	@Override
	public boolean isPlayerRegistrable(FootballPlayer player) {
		if (registeredPlayers.size() > MAX_STARTING_PLAYERS)
			throw new IllegalArgumentException(
					"Igra� " + player.getName() + " se ne mo�e registrirati jer nema mjesta u timu.");
		if (player.getPlayingSkill() < reputation)
			return false;
		return registeredPlayers.size() < MAX_STARTING_PLAYERS;
	}

}
