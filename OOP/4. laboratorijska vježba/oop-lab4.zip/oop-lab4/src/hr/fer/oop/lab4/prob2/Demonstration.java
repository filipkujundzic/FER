package hr.fer.oop.lab4.prob2;

import hr.fer.oop.lab4.prob1.Formation;

/**
 * Demonstracija drugog zadatka 4. lab. vjezbe iz OOP2015.
 *
 */
public class Demonstration {

	public static void main(String[] args) {
		System.out.println("Stvaranje novog tima...");
		ClubTeam varteks = null;
		try {
			varteks = new ClubTeam("VARTEKS", Formation.F352, 101);
		} catch (IllegalArgumentException e) {
			System.out.println("Gre�ka: " + e.toString() + "\nOporavak od pogre�ke..");
			varteks = new ClubTeam("VARTEKS", Formation.F352, 75);
		}
		System.out.println("Naziv:" + varteks.getName() + ", reputacija:" + varteks.getReputation() + ", formacija:"
				+ varteks.getFormation());
	}

}