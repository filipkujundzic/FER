package hr.fer.oop.lab4.prob2;

/**
 * Su�elje s metodama za upravljanje utakmicom
 * 
 * @author Filip Kujundzic
 * @version 1.0
 *
 */
public interface IMatchInspectableTeam {
	/**
	 * Metoda koja provjerava da li utakmica mo�e po�eti
	 * 
	 * @return true ako mo�e, false ina�e
	 */
	public boolean isMatchReady();

	/**
	 * Metoda za ra�unanje mom�adskog duha
	 * 
	 * @return mom�adski duh
	 */
	public int calculateTeamSpirit();

	/**
	 * Metoda za ra�unanje vje�tine tima
	 * 
	 * @return vje�tina tima
	 */
	public int calculateTeamSkill();

	/**
	 * Metoda za ra�unanje ratinga tima
	 * 
	 * @return rating tima
	 */
	public double calculateRating();

}
