package hr.fer.oop.lab4.prob4;

/**
 * Enumeracija koja definira mogu�e ishode utakmice
 * 
 * @author Filip Kujundzic
 *
 */
public enum MatchOutcome {
	NOT_AVAILABLE, HOME_WIN, DRAW, AWAY_WIN
}
