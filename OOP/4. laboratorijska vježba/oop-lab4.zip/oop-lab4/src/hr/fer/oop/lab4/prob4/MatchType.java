package hr.fer.oop.lab4.prob4;

/**
 * Enumeracija koja definira mogu�u vrstu utakmice
 * 
 * @author Filip Kujundzic
 * @version 1.0
 *
 */
public enum MatchType {
	FRIENDLY, COMPETITIVE
}
