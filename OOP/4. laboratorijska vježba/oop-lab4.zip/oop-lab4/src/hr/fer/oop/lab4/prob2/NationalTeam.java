package hr.fer.oop.lab4.prob2;

import java.util.LinkedHashSet;

import hr.fer.oop.lab4.prob1.FootballPlayer;
import hr.fer.oop.lab4.prob1.Formation;

/**
 * Klasa modelira nacionalni tim koji naslje�uje klasu Tim.
 * 
 * @author Filip Kujundzic
 * @version 1.0
 *
 */
public class NationalTeam extends Team {
	/**
	 * {@value #country} Naziv dr�ave
	 */
	private final String country;
	/**
	 * {@value #MAX_STARTING_PLAYERS} Maksimalan broj igra�a
	 */
	private static final int MAX_STARTING_PLAYERS = 23;

	/**
	 * Konstruktor koji omogu�ava stvaranje novog nacionalnog tima
	 * 
	 * @param name
	 *            Ime tima
	 * @param formation
	 *            Formacija tima
	 * @param country
	 *            Dr�ava tima
	 */
	public NationalTeam(String name, Formation formation, String country) {
		super(name, formation);
		if (country == null)
			throw new IllegalArgumentException("Nacionalni tim mora imati ime dr�ave.");
		this.country = country;

		registeredPlayers = new LinkedHashSet<FootballPlayer>(MAX_STARTING_PLAYERS);
	}

	/**
	 * Metoda za dohva�anje naziva dr�ave
	 * 
	 * @return naziva dr�ave
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Metoda za ra�unanje ratinga tima po formuli 0.3*mom�adski duh +
	 * 0.7*vje�tina tima
	 * 
	 * @return rating tima
	 */
	@Override
	public double calculateRating() {
		return 0.3 * this.calculateTeamSpirit() + 0.7 * calculateTeamSkill();
	}

	/**
	 * Metoda za registriranje igra�a
	 * 
	 * @param player
	 *            igra� koji se �eli registrirati
	 */
	@Override
	public void registerPlayer(FootballPlayer player) throws NotEligiblePlayerException {
		if (registeredPlayers.contains(player))
			throw new NotEligiblePlayerException(
					"Igra� " + player.getName() + " se ve� nalazi u kolekciji registriranih igra�a.");
		if (registeredPlayers.size() > MAX_STARTING_PLAYERS)
			throw new NotEligiblePlayerException(
					"Igra� " + player.getName() + " se ne mo�e registrirati jer nema mjesta u timu.");
		if (!player.getCountry().equals(country))
			throw new IllegalArgumentException(
					"Igra� " + player.getName() + "se ne mo�e registrirati jer nije iz odgovaraju�e dr�ave.");
		registeredPlayers.add(player);
	}

	/**
	 * Metoda za ispitivanje da li je mogu�e registrirati igra�a
	 * 
	 * @param player
	 *            za kojeg se ispituje da li ga je mogu�e registrirati
	 * @return true ako je mogu�e, ina�e false
	 */
	@Override
	public boolean isPlayerRegistrable(FootballPlayer player) {
		int numberOfPlayersInTeam = 11;
		if (getStartingEleven().size() == numberOfPlayersInTeam) {
			throw new IllegalArgumentException("U prvih 11 vi�e nema mjesta.");
		}
		if (!player.getCountry().equals(country)) {
			throw new IllegalArgumentException("Igra�eva dr�ava je razli�ita od dr�ave tima");
		}
		return true;
	}

}
