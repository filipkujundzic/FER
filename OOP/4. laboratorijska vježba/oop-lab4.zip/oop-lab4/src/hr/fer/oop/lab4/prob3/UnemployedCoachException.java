package hr.fer.oop.lab4.prob3;

/**
 * Klasa implementira iznimku u slu�aju nezaposlenog trenera
 * 
 * @author Filip Kujundzic
 * @version 1.0
 */
public class UnemployedCoachException extends Exception {
	/**
	 * Konstruktor koji omogu�uje stvaranje nove iznimke
	 * 
	 * @param message
	 *            poruka koju �elimo ispisati u slu�aju iznimke
	 */
	public UnemployedCoachException(String message) {
		super(message);
	}
}
