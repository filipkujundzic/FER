package hr.fer.oop.lab4.prob1;

/**
 * Klasa modelira nogometa�a te naslje�uje klasu Person.
 * 
 * @author Filip Kujundzic
 * @version 1.0
 *
 */
public class FootballPlayer extends Person {
	/**
	 * {@value #MAX_PLAYING_SKILL} najve�a mogu�a igra�eva vje�tina.
	 */
	public static final int MAX_PLAYING_SKILL = 100;
	public static final int MIN_PLAYING_SKILL = 0;
	/**
	 * {@value #playingSkill} igra�eva vje�tina (cijeli broj u rasponu [0,100];
	 */
	private int playingSkill;
	/**
	 * {@value pozicija na kojoj igra� igra u timu}
	 */
	PlayingPosition position;

	/**
	 * Konstruktor koji omogu�uje stvaranje novog nogometa�a
	 * 
	 * @param name
	 *            igra�evo ime
	 * @param country
	 *            igra�eva dr�ava
	 * @param emotion
	 *            igra�eva emocija (cijeli broj u rasponu [0,100]
	 * @param playingSkill
	 *            igra�eva vje�tina (cijeli broj u rasponu [0,100]
	 * @param position
	 *            pozicija na kojoj igra� igra
	 */
	public FootballPlayer(String name, String country, int emotion, int playingSkill, PlayingPosition position) {
		super(name, country, emotion);
		if (name == null) {
			throw new IllegalArgumentException("Ime ne smije biti null!");
		}
		this.playingSkill = playingSkill;
		if (playingSkill < MIN_PLAYING_SKILL || playingSkill > MAX_PLAYING_SKILL) {
			throw new IllegalArgumentException("Igraceva vjestina mora biti u rasponu [0,100] a ne: " + playingSkill);
		}
		this.position = position;
	}

	/**
	 * Metoda za dohva�anje vje�tine nogometa�a
	 * 
	 * @return nogometa�eva vje�tina
	 */
	public int getPlayingSkill() {
		return playingSkill;
	}

	/**
	 * Metoda za postavljanje vje�tine nogometa�a
	 * 
	 * @param playingskill
	 *            vje�tina koja se �eli postaviti
	 */
	public void setPlayingSkill(int playingskill) {
		this.playingSkill = playingskill;
	}

	/**
	 * Metoda za dohva�anje pozicije na kojoj igra� igra
	 * 
	 * @return pozicija na kojoj igra� igra
	 */
	public PlayingPosition getPlayingPosition() {
		return position;
	}

	/**
	 * Metoda za postavljanje pozicije na kojoj igra� igra
	 * 
	 * @param position
	 *            pozicija koja se �eli postaviti
	 */
	public void setPlayingPosition(PlayingPosition position) {
		this.position = position;
	}

}
