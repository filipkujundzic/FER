package hr.fer.oop.lab4.prob4;

import static java.lang.Math.min;

import java.util.Random;

import hr.fer.oop.lab4.prob2.IMatchInspectableTeam;

/**
 * Klasa predstavlja simulaciju nogometne utakmice
 * 
 * @author Filip Kujundzic
 * @version 1.0
 */
public class Match implements IPlayableMatch {
	/**
	 * {@value #home} Doma�i tim koji igra utakmicu
	 */
	public final IMatchInspectableTeam home;
	/**
	 * {@value #away} Gostuju�i tim koji igra utakmicu
	 */
	public final IMatchInspectableTeam away;
	/**
	 * {@value #type} tip utakmice
	 */
	public final MatchType type;
	/**
	 * {@value #outcome} ishod utakmice
	 */
	public MatchOutcome outcome = MatchOutcome.NOT_AVAILABLE;

	/**
	 * Konstruktor koji stvara novu utakmicu
	 * 
	 * @param home
	 *            Doma�i tim
	 * @param away
	 *            Gostuu�i tim
	 * @param type
	 *            Tip utakmice
	 */
	public Match(IMatchInspectableTeam home, IMatchInspectableTeam away, MatchType type) {
		if (home == null)
			throw new IllegalArgumentException("Utakmica mora imati doma�i tim.");
		this.home = home;
		if (away == null)
			throw new IllegalArgumentException("Utakmica mora imati gostoju�i tim.");
		this.away = away;
		if (type == null)
			throw new IllegalArgumentException("Utakmica mora biti prijateljska ili natjecateljska.");
		this.type = type;
	}

	/**
	 * Metoda koja simulira igranje utakmice te postavlja rezultat u varijablu
	 * outcome (ra�una ju pomo�u slu�ajnih vrijednosti)
	 */
	@Override
	@SuppressWarnings("static-access")
	public void play() throws NotPlayableMatchException {
		if (!home.isMatchReady())
			throw new NotPlayableMatchException("Utakmica se ne mo�e odigrati jer doma�i tim nije spreman.");
		if (home == null)
			throw new NotPlayableMatchException("Utakmica se ne mo�e odigrati jer doma�i tim nije postavljen");
		if (!away.isMatchReady())
			throw new NotPlayableMatchException("Utakmica se ne mo�e odigrati jer gostoju�i tim nije spreman.");
		if (away == null)
			throw new NotPlayableMatchException("Utakmica se ne mo�e odigrati jer gostuju�i tim nije postavljen");
		if (type == null)
			throw new NotPlayableMatchException("Utakmica se ne mo�e odigrati jer nije postavljen tip utakmice");
		if (type.equals(MatchType.COMPETITIVE)) {
			if (home.getClass().equals(away.getClass()))
				throw new NotPlayableMatchException(
						"Natjecateljska utakmica se ne mo�e odigrati osim ako oba tima nisu istog tipa");
		}

		double h = home.calculateRating() / (home.calculateRating() + away.calculateRating());
		double a = away.calculateRating() / (home.calculateRating() + away.calculateRating());
		double min = min(h, a);

		double random = new Random().nextDouble();
		if (random < h - min / 2) {
			outcome = outcome.AWAY_WIN;
		} else if (random > h + min / 2) {
			outcome = outcome.HOME_WIN;
		} else {
			outcome = outcome.DRAW;
		}
	}

	/**
	 * Metoda za dohva�anje doma�eg tima
	 * 
	 * @return doma�i tim
	 */
	public IMatchInspectableTeam getHome() {
		return home;
	}

	/**
	 * Metoda za dohva�anje gostuju�eg tima
	 * 
	 * @return gostuju�i tim
	 */
	public IMatchInspectableTeam getAway() {
		return away;
	}

	/**
	 * Metoda za dohva�anje tipa utakmice
	 * 
	 * @return tip utakmice
	 */
	public MatchType getType() {
		return type;
	}

	/**
	 * Metoda za dohva�anje ishoda utakmice
	 * 
	 * @return ishod utakmice
	 */
	public MatchOutcome getOutcome() {
		return outcome;
	}

}
