package hr.fer.oop.lab4.prob1;

import java.util.function.Predicate;

import hr.fer.oop.lab4.prob2.IManageableTeam;
import hr.fer.oop.lab4.prob2.NotEligiblePlayerException;
import hr.fer.oop.lab4.prob3.IManager;
import hr.fer.oop.lab4.prob3.UnemployedCoachException;

/**
 * 
 * Klasa modelira trenera nogometnog tima te naslje�uje apstraktnu klasu Person
 * i implementira su�elje IManager.
 * 
 * @author Filip Kujundzic
 * @version 1.0
 * 
 */
public class Coach extends Person implements IManager {

	/**
	 * {@value #coachingSkill} Trenerova vje�tina (cijeli broj u intervalu
	 * [0,100])
	 */
	private int coachingSkill;
	/**
	 * {@value #favoriteFormation} Trenerova omiljena formacija tima.
	 */
	private Formation favoriteFormation;
	/**
	 * {@value #MAXMAX_COACH_SKILL} najve�a vrijednost trenerove vje�tine
	 */
	private static final int MAXMAX_COACH_SKILL = 100;
	/**
	 * {@value #MIN_COACH_SKILL} najve�a vrijednost trenerove vje�tine
	 */
	private static final int MIN_COACH_SKILL = 0;
	/**
	 * {@value #managingTeam} Varijabla tipa ImanageableTeam preko koje trener
	 * upravlja timom.
	 */
	private IManageableTeam managingTeam;

	/**
	 * Konstruktor koji omogu�uje stvaranje novog trenera.
	 * 
	 * @param name
	 *            Trenerovo ime.
	 * @param country
	 *            Trenerova dr�ava.
	 * @param emotion
	 *            Trenerova emocija.
	 * @param coachingskill
	 *            Trenerova vje�tina (cijeli broj u intervalu [0,100]);
	 * @param favoriteFormation
	 *            Trenerova omiljena formacija.
	 */
	public Coach(String name, String country, int emotion, int coachingSkill, Formation favoriteFormation) {
		super(name, country, emotion);
		if (name == null) {
			throw new IllegalArgumentException("Ime ne smije biti null!");
		}
		if (coachingSkill < MIN_COACH_SKILL || MAXMAX_COACH_SKILL > 100) {
			throw new IllegalArgumentException("Trenerova vje�tina mora biti u rasponu [0,100] a ne: " + coachingSkill);
		}
		this.coachingSkill = coachingSkill;
		this.favoriteFormation = favoriteFormation;
	}

	/**
	 * Metoda za dohva�anje trenerove vje�tine.
	 * 
	 * @return vrijednost trenerove vje�tine.
	 */
	public int getCoachingskill() {
		return coachingSkill;
	}

	/**
	 * Metoda za postavljanje trenerove vje�tine.
	 * 
	 * @param coachingSkill
	 *            Vrijednost trenerove vje�tine koja se �eli postaviti.
	 * 
	 */
	public void setCoachingSkill(int coachingSkill) {
		if (coachingSkill < MIN_COACH_SKILL || MAXMAX_COACH_SKILL > 100) {
			throw new IllegalArgumentException("Trenerova vje�tina mora biti u rasponu [0,100] a ne: " + coachingSkill);
		}
		this.coachingSkill = coachingSkill;
	}

	/**
	 * Metoda za dohva�anje trenerove omiljene formacije.
	 * 
	 * @return trenerova omijena formacija.
	 */
	public Formation getFavoriteFormation() {
		return favoriteFormation;
	}

	/**
	 * Metoda za postavljanje omiljene trenerove formacije.
	 * 
	 * @param favoriteFormation
	 *            formacija koja se �eli postaviti kao trenerova omiljena.
	 */
	public void setFavoriteFormation(Formation favoriteFormation) {
		this.favoriteFormation = favoriteFormation;
	}

	/**
	 * Metoda za dohva�anje tima kojeg trener trenira
	 * 
	 * @return tim kojeg trener trenira
	 */
	public IManageableTeam getManagingTeam() {
		return managingTeam;
	}

	/**
	 * Metoda za postavljanje tima kojeg trener trenira.
	 * 
	 * @param team
	 *            tim koji se �eli postaviti treneru da ga trenira.
	 */
	@Override
	public void setManagingTeam(IManageableTeam team) {
		this.managingTeam = team;
	}

	/**
	 * Metoda za registraciju igra�a.
	 * 
	 * @param offeredPlayers
	 *            kolekcija igra�a ponu�enih treneru za izbor
	 * @param criteria
	 *            kriterij prema kojem se odabiru igra�i u tim
	 * @throws NotEligiblePlayerException
	 *             ako igra� nije kvalificiran
	 */
	@Override
	public void registerPlayers(Iterable<FootballPlayer> offeredPlayers, Predicate<FootballPlayer> criteria)
			throws NotEligiblePlayerException {
		for (FootballPlayer player : offeredPlayers) {
			if (criteria.test(player)) {
				managingTeam.registerPlayer(player);
			}

		}
	}

	/**
	 * Metoda za odabir po�etnih 11 igra�a u tim.
	 * 
	 * @param criteria
	 *            kriterij prema kojem se odabire po�etnih 11 igra�a u tim
	 * 
	 */
	@Override
	public void pickStartingEleven(Predicate<FootballPlayer> criteria) throws UnemployedCoachException {
		if (managingTeam == null) {
			throw new UnemployedCoachException("Trener je nezaposlen!");
		}
		managingTeam.clearStartingEleven();

		final int POSITIONS_NUMBER = 3;
		int[] form = new int[POSITIONS_NUMBER];
		int gk = 0;
		for (int i = 0; i < POSITIONS_NUMBER; i++) {
			form[i] = Character.getNumericValue(managingTeam.getFormation().toString().charAt(i + 1));
		}

		for (FootballPlayer player : managingTeam.getRegisteredPlayers())
			if (criteria.test(player)) {
				switch (player.getPlayingPosition()) {
				case GK: {
					if (gk < 1) {

						try {
							managingTeam.addPlayerToStartingEleven(player);
						} catch (NotEligiblePlayerException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						gk++;
					}
					break;
				}
				case DF: {
					if (form[0] > 0) {
						form[0]--;

						try {
							managingTeam.addPlayerToStartingEleven(player);
						} catch (NotEligiblePlayerException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					break;
				}
				case MF: {
					if (form[1] > 0) {
						form[1]--;

						try {
							managingTeam.addPlayerToStartingEleven(player);
						} catch (NotEligiblePlayerException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					break;
				}
				case FW: {
					if (form[2] > 0) {
						form[2]--;

						try {
							managingTeam.addPlayerToStartingEleven(player);
						} catch (NotEligiblePlayerException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					break;
				}
				default:
					break;
				}
			}
	}

	/**
	 * Metoda za forsiranje formacije. Timu kojeg trener trenira postavlja se
	 * trenerova omiljena formacija.
	 */
	@Override
	public void forceMyFormation() throws UnemployedCoachException {
		if (managingTeam == null) {
			throw new UnemployedCoachException("Trener nije zaposlen!");
		}
		managingTeam.setFormation(favoriteFormation);
	}

}
