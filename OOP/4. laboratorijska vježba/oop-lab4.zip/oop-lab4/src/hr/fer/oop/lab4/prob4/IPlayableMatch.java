package hr.fer.oop.lab4.prob4;

/**
 * Su�elje s metodom za igranje utakmice
 * 
 * @author Filip Kujundzic
 * @version 1.0
 *
 */
public interface IPlayableMatch {
	/**
	 * Metoda za igranje utakmice
	 * 
	 * @throws NotPlayableMatchException
	 *             u slu�aju da se utakmica ne mo�e igrati
	 */
	void play() throws NotPlayableMatchException;
}
