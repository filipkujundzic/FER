package hr.fer.oop.lab4.prob2;

/**
 * Klasa koja implementira iznimku u slu�aju nekvalificiranog igra�a
 * 
 * @author Filip Kujundzic
 * @version 1.0
 */
public class NotEligiblePlayerException extends Exception {
	/**
	 * Konstruktor koji omogu�uje stvaranje nove iznimke
	 * 
	 * @param message
	 *            Poruka koju �elimo ispisati u slu�aju iznimke
	 */
	public NotEligiblePlayerException(String message) {
		super(message);
	}
}
