package hr.fer.oop.lab4.prob2;

import java.util.Collection;
import java.util.function.Predicate;

import hr.fer.oop.lab4.prob1.FootballPlayer;
import hr.fer.oop.lab4.prob1.Formation;

/**
 * Su�elje s metodama za upravljanje timom
 * 
 * @author Filip Kujundzic
 * @version 1.0
 */
public interface IManageableTeam {
	/**
	 * Metoda za registriranje igra�a
	 * 
	 * @param player
	 *            igra� kojeg se �eli registrati
	 * @throws NotEligiblePlayerException
	 *             ako je igra� nekvalificiran
	 */
	public void registerPlayer(FootballPlayer player) throws NotEligiblePlayerException;

	/**
	 * Metoda za poni�tavanje registracije igra�a
	 * 
	 * @param player
	 *            igra� kojem se �eli poni�titi registracija
	 * @throws IllegalArgumentException
	 *             u slu�aju krivog argumenta
	 */
	public void unregisterPlayer(FootballPlayer player) throws IllegalArgumentException;

	/**
	 * Metoda za brisanje po�etnih 11 iz tima
	 */
	public void clearStartingEleven();

	/**
	 * Metoda za dodavanje igra�a u po�etnih 11
	 * 
	 * @param player
	 *            igra� kojeg �elimo dodati u po�etnih 11
	 * @throws NotEligiblePlayerException
	 *             ako nije mogu�e dodati igra�a
	 */
	public void addPlayerToStartingEleven(FootballPlayer player) throws NotEligiblePlayerException;

	/**
	 * Metoda za uklanjanje igra�a iz po�etnih 11
	 * 
	 * @param player
	 *            igra� kojeg �elimo ukloniti iz po�etnih 11
	 * @throws IllegalArgumentException
	 *             u slu�aju krivog argumenta
	 */
	public void removePlayerFromStartingEleven(FootballPlayer player) throws IllegalArgumentException;;

	/**
	 * Metoda koja ispituje da li je mogu�e registrirati igra�a.
	 * 
	 * @param player
	 *            igra� za kojeg �elimo ispitati da li ga je mogu�e registrirati
	 * @return true ako je mogu�e registrirati igra�a, false ina�e
	 */
	public boolean isPlayerRegistrable(FootballPlayer player);

	/**
	 * Metoda za dohva�anje kolekcije registriranih igra�a
	 * 
	 * @return kolekcija registriranih igra�a
	 */
	public Collection<FootballPlayer> getRegisteredPlayers();

	/**
	 * Metoda za dohva�anje kolekcije po�etnih 11 igra�a
	 * 
	 * @return kolekcija s 11 po�etnih igra�a
	 */
	public Collection<FootballPlayer> getStartingEleven();

	/**
	 * Metoda za filtriranje registriranih igra�a
	 * 
	 * @param criteria
	 *            kriterij prema kojem se igra�i filtriraju
	 * @return kolekcija profiltriranih igra�a
	 */
	public Collection<FootballPlayer> filterRegisteredPlayers(Predicate<FootballPlayer> criteria);

	/**
	 * Metoda za postavljanje formacije
	 * 
	 * @param formation
	 *            formacija koja se �eli postaviti
	 */
	public void setFormation(Formation formation);

	/**
	 * Metoda za dohva�anje formacije tima
	 * 
	 * @return formacija tima
	 */
	public Formation getFormation();

}
