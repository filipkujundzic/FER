package hr.fer.oop.lab4.prob2;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.function.Predicate;

import hr.fer.oop.lab4.prob1.FootballPlayer;
import hr.fer.oop.lab4.prob1.Formation;

/**
 * Klasa modelira Tim te implementira su�elja IManageableTeam te
 * IMatchInspectableTeam
 * 
 * @author Filip Kujundzic
 * @version 1.0
 *
 */
public abstract class Team implements IManageableTeam, IMatchInspectableTeam {
	/**
	 * {@value #name} Ime tima
	 */
	private final String name;
	/**
	 * {@value #formation} Formacija tima
	 */
	private Formation formation;
	/**
	 * {@value #registeredPlayers} Kolekcija registriranih igra�a
	 */
	protected Collection<FootballPlayer> registeredPlayers;
	/**
	 * {@value #startingEleven} Kolekcija po�etne jedanaestorice
	 */
	private Collection<FootballPlayer> startingEleven;
	/**
	 * {@value Team#STARTING_ELEVEN_SIZE} Veli�ina tima
	 */
	public static final int STARTING_ELEVEN_SIZE = 11;
	/**
	 * {@value #MIN_START_PLAYERS} Minimalana veli�ina tima
	 */
	private static final int MIN_START_PLAYERS = 7;

	/**
	 * Konstruktor koji omogu�uje stvaranje tima
	 * 
	 * @param name
	 *            ime tima
	 * @param formation
	 *            formacija tima
	 */
	public Team(String name, Formation formation) {
		if (name == null)
			throw new IllegalArgumentException("Ime ne smije biti null.");
		this.name = name;
		if (formation == null)
			throw new IllegalArgumentException("Formacija ne smije biti null.");
		this.formation = formation;

		startingEleven = new LinkedHashSet<FootballPlayer>(STARTING_ELEVEN_SIZE);
	}

	/**
	 * Metoda za dohva�anje imena tima
	 * 
	 * @return ime tima
	 */
	public String getName() {
		return name;
	}

	/**
	 * Metoda za dohva�anje formacije tima
	 * 
	 * @return formacija tima
	 */
	@Override
	public Formation getFormation() {
		return formation;
	}

	/**
	 * Metoda za poni�tavanje registracije igra�a
	 * 
	 * @param player
	 *            Igra� �ija se registracija �eli poni�titi
	 */
	@Override
	public void unregisterPlayer(FootballPlayer player) throws IllegalArgumentException {
		if (!registeredPlayers.contains(player)) {
			throw new IllegalArgumentException("Igra� " + player + " ne nalazi se u kolekciji registriranih igra�a");
		}
		registeredPlayers.remove(player);
	}

	/**
	 * Metoda za dodavanje igra�a u po�etnih 11
	 * 
	 * @param player
	 *            igra� koji se �eli dodati u po�etnih 11
	 */
	@Override
	public void addPlayerToStartingEleven(FootballPlayer player) throws NotEligiblePlayerException {
		if (!registeredPlayers.contains(player)) {
			throw new NotEligiblePlayerException("Igra� " + player.getName() + " nije registriran");
		}
		if (startingEleven.size() > 11) {
			throw new NotEligiblePlayerException("U prvih 11 nema dovoljno mjesta");
		}
		if (startingEleven.contains(player))
			throw new NotEligiblePlayerException("Igra� se ve� nalazi u prvih 11 tima" + this.name);
		startingEleven.add(player);
	}

	/**
	 * Metoda za uklanjanje igra�a iz po�etne jedanaestorice
	 * 
	 * @param player
	 *            igra� kojeg �elimo ukloniti iz po�etne jedanaestorice
	 */
	@Override
	public void removePlayerFromStartingEleven(FootballPlayer player) throws IllegalArgumentException {
		if (startingEleven.contains(player) == false) {
			throw new IllegalArgumentException("Igra� " + player + " ne nalazi se u prvih 11.");
		}
		startingEleven.remove(player);
	}

	/**
	 * Metoda za brisanje kolekcije u kojoj je 11 igra�a iz tima
	 */
	@Override
	public void clearStartingEleven() {
		startingEleven.clear();
	}

	/**
	 * Metoda za dohva�anje kolekcije registriranih igra�a
	 * 
	 * @return kolekcija registriranih igra�a
	 */
	@Override
	public Collection<FootballPlayer> getRegisteredPlayers() {

		return new LinkedHashSet<FootballPlayer>(registeredPlayers);
	}

	/**
	 * Metoda za filtriranje registriranih igra�a
	 * 
	 * @param criteria
	 *            kriterij prema kojem se igra�i filtriraju
	 * @return kolekcija profiltriranih igra�a
	 */
	@Override
	public Collection<FootballPlayer> filterRegisteredPlayers(Predicate<FootballPlayer> criteria) {
		Collection<FootballPlayer> filtered;
		filtered = new LinkedHashSet<>();
		for (FootballPlayer player : registeredPlayers) {
			if (criteria.test(player)) {
				filtered.add(player);
			}
		}
		return filtered;
	}

	/**
	 * Metoda za dohva�anje kolekcije po�etnih 11
	 * 
	 * @return kolekcija s po�etnih 11 igra�a
	 */
	@Override
	public Collection<FootballPlayer> getStartingEleven() {
		return new LinkedHashSet<FootballPlayer>(startingEleven);
	}

	/**
	 * Metoda za ra�uanje vje�tine tima
	 * 
	 * @return vje�tina tima
	 */
	@Override
	public int calculateTeamSkill() {
		int skill = 0;
		for (FootballPlayer i : startingEleven) {
			skill += i.getPlayingSkill();
		}
		return skill;
	}

	/**
	 * Metoda za ra�unanje mom�adskog duha
	 * 
	 * @return mom�adski duh
	 */
	@Override
	public int calculateTeamSpirit() {
		int spirit = 0;
		for (FootballPlayer i : startingEleven) {
			spirit += i.getEmotion();
		}
		return spirit;
	}

	/**
	 * Metoda koja ispituje da li je tim spreman za utakmicu
	 * 
	 * @return true ako je spreman, ina�e false
	 */
	@Override
	public boolean isMatchReady() {
		if (startingEleven.size() >= MIN_START_PLAYERS)
			return true;
		return false;
	}

	/**
	 * Metoda za postavljanje formacije tima
	 * 
	 * @param formation
	 *            formacija koja se �eli postaviti
	 */
	@Override
	public void setFormation(Formation formation) {
		this.formation = formation;
	}

}
