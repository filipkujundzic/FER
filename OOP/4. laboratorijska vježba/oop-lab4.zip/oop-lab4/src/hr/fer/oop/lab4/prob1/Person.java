package hr.fer.oop.lab4.prob1;

import java.util.Objects;

/**
 * Klasa modelira osobu.
 * 
 * @author Filip Kujundzic
 * @version 1.0
 */
public abstract class Person {
	/**
	 * {@value #name} Ime osobe
	 */
	private final String name;
	/**
	 * {@value #country} Dr�ava osobe
	 */
	private final String country;
	/**
	 * {@value #emotion} Emocija osobe (cijeli broj u rasponu [0,100])
	 */
	private final int emotion;
	/**
	 * {@value #MAX_EMOTION} Najve�a mogu�a emocija
	 */
	private static final int MAX_EMOTION = 100;
	/**
	 * {@value #MIN_EMOTION} Najmanja mogu�a emocija
	 */
	private static final int MIN_EMOTION = 0;

	/**
	 * Konstruktor koji omogu�ava stvaranje osobe
	 * 
	 * @param name
	 *            ime osobe
	 * @param country
	 *            dr�ava osobe
	 * @param emotion
	 *            emocija osobe (cijeli broj u rasponu [0,100])
	 */
	public Person(String name, String country, int emotion) {
		if (name == null) {
			throw new IllegalArgumentException("Ime ne smije biti null!");
		}
		this.name = name;
		this.country = country;
		if (emotion < MIN_EMOTION || emotion > MAX_EMOTION) {
			throw new IllegalArgumentException("Emocija mora biti u rasponu [0,100] a ne: " + emotion);
		}
		this.emotion = emotion;
	}

	/**
	 * Metoda za dohva�anje imena osobe
	 * 
	 * @return ime osobe
	 */
	public String getName() {
		return name;
	}

	/**
	 * Metoda za dohva�anje dr�ave osobe
	 * 
	 * @return dr�ava osobe
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Metoda za dohva�anje emocije osobe
	 * 
	 * @return emocija osobe
	 */
	public int getEmotion() {
		return emotion;
	}

	/**
	 * Metoda za ra�unanje hash vrijednosti objekta
	 * 
	 * @return hash vrijednost objekta
	 */
	@Override
	public int hashCode() {
		int hash = 3;
		hash = 17 * hash + Objects.hashCode(this.name);
		hash = 17 * hash + Objects.hashCode(this.country);
		hash = 17 * hash + this.emotion;
		return hash;
	}

	/**
	 * Metoda za odre�ivanje da li su objekti jednaki ili ne
	 * 
	 * @return true ako su jednaki, ina�e false
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		if (emotion != other.emotion)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
}
