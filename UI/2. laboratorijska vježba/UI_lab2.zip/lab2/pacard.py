
"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
from logic import * 

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
        state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
        actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def miniWumpusSearch(problem): 
    """
    A sample pass through the miniWumpus layout. Your solution will not contain 
    just three steps! Optimality is not the concern here.
    """
    from game import Directions
    e = Directions.EAST 
    n = Directions.NORTH
    return  [e, n, n]

def logicBasedSearch(problem):
    """

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())

    print "Does the Wumpus's stench reach my spot?", 
               \ problem.isWumpusClose(problem.getStartState())

    print "Can I sense the chemicals from the pills?", 
               \ problem.isPoisonCapsuleClose(problem.getStartState())

    print "Can I see the glow from the teleporter?", 
               \ problem.isTeleporterClose(problem.getStartState())
    
    (the slash '\\' is used to combine commands spanning through multiple lines - 
    you should remove it if you convert the commands to a single line)
    
    Feel free to create and use as many helper functions as you want.

    A couple of hints: 
        * Use the getSuccessors method, not only when you are looking for states 
        you can transition into. In case you want to resolve if a poisoned pill is 
        at a certain state, it might be easy to check if you can sense the chemicals 
        on all cells surrounding the state. 
        * Memorize information, often and thoroughly. Dictionaries are your friends and 
        states (tuples) can be used as keys.
        * Keep track of the states you visit in order. You do NOT need to remember the
        tranisitions - simply pass the visited states to the 'reconstructPath' method 
        in the search problem. Check logicAgents.py and search.py for implementation.
    """
    # array in order to keep the ordering
    visitedStates = []
    startState = problem.getStartState()
    visitedStates.append(startState)
    """
    ####################################
    ###                              ###
    ###        YOUR CODE HERE        ###
    ###                              ###
    ####################################
    """

    informations = dict()
    safeStatesContainer = set()
    safeStates = set()
    notSafeStates = set()
    unsureStates = set()
    currentState = startState
    wumpusLocation = None

    while True:
        print "\nMy location is", currentState

        if problem.isGoalState(currentState):
            print "I find a teleporter!"
            return problem.reconstructPath(visitedStates)
        elif problem.isWumpus(currentState) or problem.isPoisonCapsule(currentState):
            print "Pacard is dead."
            return problem.reconstructPath(visitedStates)

        Stench = problem.isWumpusClose(currentState)
        Chemicals = problem.isPoisonCapsuleClose(currentState)
        Glow = problem.isTeleporterClose(currentState)
        informations.setdefault(currentState, {}).update({'S': Stench, 'C': Chemicals, 'G': Glow, 'O': True})

        nextStates = []
        for state in problem.getSuccessors(currentState):
        	nextStates.append(state[0]) # state[0] == position(state)

        for state in nextStates:
            if (state not in visitedStates) and (state not in notSafeStates):
                knowledgeForState = informations.setdefault(state, {})

                print "\n State:", state
                clauses = getClauses(nextStates, currentState, informations, wumpusLocation)

                Wumpus = checkConclusion(knowledgeForState, clauses, state, 'W')
                Poison = checkConclusion(knowledgeForState, clauses, state, 'P')
                Teleporter = checkConclusion(knowledgeForState, clauses, state, 'T')
                Ok = checkConclusion(knowledgeForState, clauses, state, 'O')

                knowledgeForState.update({'W': Wumpus, 'P': Poison, 'T': Teleporter, 'O': Ok})
                print "\t W: ", Wumpus, ", P: ", Poison, ", T: ", Teleporter, ", O: ", Ok

                if Teleporter:
                    currentState = state
                    visitedStates.append(currentState)
                    return problem.reconstructPath(visitedStates)

                elif Ok:
                    if state not in safeStatesContainer:
                        if state in unsureStates:
                            unsureStates.remove(state)
                        safeStatesContainer.add(state)
                        safeStates.add(state)

                elif Poison:
                    if state in unsureStates:
                        unsureStates.remove(state)
                    notSafeStates.add(state)

                elif Wumpus:
                    if state in unsureStates:
                        unsureStates.remove(state)
                    notSafeStates.add(state)
                    wumpusLocation = state   
                else:
                    unsureStates.add(state)

        if safeStatesContainer:
            currentState = minStateWeight(list(safeStatesContainer))
            safeStatesContainer.remove(currentState)
        elif unsureStates:
            found = False
            unsure = set()
            state = None
            while unsureStates and not found:
                state = minStateWeight(list(unsureStates))
                unsureStates.remove(state)

                Wumpus = informations.setdefault(state, {}).get('W', None)
                Poison = informations.setdefault(state, {}).get('P', None)
                Teleporter = informations.setdefault(state, {}).get('T', None)
                Ok = informations.setdefault(state, {}).get('O', None)
      
                if Wumpus or Poison:
                    continue

                if Ok:
                    found = True
                elif not Wumpus and not Poison:
                    if (Wumpus is not None) and (Poison is not None):
                        found = True
                    else:
                        unsure.add(state)

            unsureStates = unsureStates.union(unsure)
            if found:
                currentState = state
            elif unsureStates:
                currentState = minStateWeight(list(unsureStates))
                unsureStates.remove(currentState)
            else:
                print "I don't want to go there!"
                return problem.reconstructPath(visitedStates)

        else:
            print "I don't want to go there!"
            return problem.reconstructPath(visitedStates)

        visitedStates.append(currentState)


def minStateWeight(states):
    minState = states[0]
    min = stateWeight(states[0])
    for state in states[1:]:
        if stateWeight(state) < min:
            min = stateWeight(state)
            minState = state

    return minState


def checkConclusion(knowledgeForState, clauses, state, label):
    conclusion = knowledgeForState.get(label, None)

    if conclusion is not None:
        return conclusion
    else:
        conclusion = resolution(clauses, Clause(Literal(label, state, False)))
        if conclusion:
            return conclusion
        elif conclusion != resolution(clauses, Clause(Literal(label, state, True))):
            return conclusion
        else:
            return None


def getClauses(nextStates, currentState, informations, wumpusLocation):
    Stench = informations.setdefault(currentState, {}).get('S', None)
    Chemicals = informations.setdefault(currentState, {}).get('C', None)
    Glow = informations.setdefault(currentState, {}).get('G', None)

    print "\t Sensed S: ", Stench
    print "\t Sensed C: ", Chemicals
    print "\t Sensed G: ", Glow

    WClauses = set()
    if Stench:
        literals = set()
        for state in nextStates:
            Wumpus = informations.setdefault(state, {}).get('W', None)
            if Wumpus is not None:
                WClauses.add(Clause({Literal('W', state, not Wumpus)}))
            else:
                if wumpusLocation is not None:
                    WClauses.add(Clause({Literal('W', state, not (state == wumpusLocation))}))
                else:
                    literals.add(Literal('W', state, False))

        WClauses.add(Clause(literals))
    else:
        for state in nextStates:
            WClauses.add(Clause({Literal('W', state, True)}))
            informations.setdefault(state, {}).update({'W': False})

    TClauses = set()
    if Glow:
        literals = set()
        for state in nextStates:
            literals.add(Literal('T', state, False))
        TClauses.add(Clause(literals))
    else:
        for state in nextStates:
            TClauses.add(Clause({Literal('T', state, True)}))
            informations.setdefault(state, {}).update({'T': False})

    PClauses = set()
    if Chemicals:
        literals = set()
        for state in nextStates:
            Poison = informations.setdefault(state, {}).get('P', None)
            if Poison is not None:
                PClauses.add(Clause({Literal('P', state, not Poison)}))
            else:
                literals.add(Literal('P', state, False))
        PClauses.add(Clause(literals))
    else:
        for state in nextStates:
            PClauses.add(Clause({Literal('P', state, True)}))
            informations.setdefault(state, {}).update({'P': False})

    OClauses = set()
    if not Chemicals and not Stench:
        for state in nextStates:
            OClauses.add(Clause({Literal('O', state, False)}))
            informations.setdefault(state, {}).update({'O': True})

    for state in nextStates:
        Wumpus = informations.setdefault(state, {}).get('W', None)
        Poison = informations.setdefault(state, {}).get('P', None)

        if (Wumpus is not None) or (Poison is not None):
            OClauses.add(Clause({Literal('O', state, True)}))
            informations.setdefault(state, {}).update({'O': False})

        elif (Wumpus is not None) and (Poison is not None) and (not Wumpus) and (not Poison):
            OClauses.add(Clause({Literal('O', state, False)}))
            informations.setdefault(state, {}).update({'O': True})

    clauses = WClauses.union(PClauses).union(TClauses).union(OClauses)
    print clauses
    return clauses

"""
        ####################################
        ###                              ###
        ###      YOUR CODE EVERYWHERE    ###
        ###                              ###
        ####################################
"""

# Abbreviations
lbs = logicBasedSearch
