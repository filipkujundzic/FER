### Lab assignment 1

This is the repository for the code of the first lab assignment. You can find the instructions for the lab assignment in both Croatian and English in their folder [here](instructions/).

![Depth first search](https://github.com/mttk/AIclass/blob/master/lab1/misc/DFS_example.png)
